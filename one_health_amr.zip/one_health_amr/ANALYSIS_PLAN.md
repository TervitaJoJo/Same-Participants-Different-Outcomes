# Analysis plan: public NARMS One Health extension

Written on 2026-10-15 before downloading the full surveillance metadata or
calculating any source-association estimates. The previous feasibility check
inspected a nonrandom file prefix and established 124 candidate records.
This dated local plan is not a prospectively registered protocol.

## Question and unit

Does the association between retail meat source and a binary AMR indicator
change when the same Salmonella isolate is classified by tetracycline AST
versus detected tetracycline-class resistance determinants?

The unit is an isolate/BioSample. These indicators represent phenotypic
resistance and genomic determinant detection, respectively. Determinant
detection is not automatically a validated drug-specific phenotype prediction.

## Data and inclusion

- NCBI Pathogen Detection release PDG000000002.4261, Salmonella AMR TSV.
- The entire official metadata file will be streamed and checked. The pilot
  prefix will not be used as an analytical sample or extrapolated.
- Records with a project_name containing NARMS, or BioProject PRJNA292661
  (official title CVM NARMS Salmonella).
- USA collection location; collection year 2002 through 2023 inclusive.
- Exact source labels (case and whitespace normalized): chicken breast,
  ground turkey, ground beef, pork chop. These identify food records and
  must not be relabeled as environmental samples or animal clinical samples.
- AMRFinderPlus completed and reference database 2025-12-03.1.
- Quality filters: assembly length 4-6 Mb, <=500 contigs, N50 >=20 kb.
- Deduplicate BioSamples. Conflicting source, AST or genomic calls exclude
  the BioSample. Otherwise prefer the assembly with greatest N50, fewest
  contigs, and lexical target accession as a deterministic final tie-breaker.
- Record exclusions and retain all source groups regardless of estimates.

## Paired indicators and exposure

- M = 1 for tetracycline AST R; M = 0 for S. Exclude I, ND and missing
  classifications in the primary analysis.
- S = 1 for at least one complete core AMR determinant whose official
  ReferenceGeneCatalog class includes the token TETRACYCLINE. Match gene
  families and alleles exactly against the pinned catalog. S = 0 when a
  completed run has no matching determinant. A matching PARTIAL call without
  a complete match, or an unmapped tet-family call, is ambiguous and excluded.
- Report the complete mapping and observed mapped symbols. This is a
  catalog-defined tetracycline-class determinant indicator.
- Main exposure E = 1 ground turkey, E = 0 chicken breast.
- Secondary comparisons: ground beef vs chicken breast; pork chop vs chicken
  breast. The processing/source contrast is descriptive and does not identify
  a causal effect of animal species or a transmission pathway.

## Estimation and uncertainty

- Primary: empirical joint-state probabilities by source (a saturated
  source-only multinomial model). Report kappa, disagreement, both ORs,
  Delta_c, and order-symmetric C_U/C_V. With no adjustment covariates,
  Delta_m equals Delta_c. Use the manuscript's state order 00,V,U,11 and
  Delta = logOR(S) - logOR(M).
- Use the manuscript allocation identity from the existing analysis code.
- Paired source-stratified multinomial bootstrap of isolate counts, 2,000
  attempted replicates, seed 2026101501. This is equivalent to resampling
  paired isolate records within source for this saturated model.
- Require positive support in all eight source-by-state cells for the
  selected full-state inference procedure. Retain every failed replicate
  and reason. Report percentile 95% intervals conditional on success plus
  the attempt/success denominators. No truth/coverage claim applies to
  empirical bootstrap intervals.
- Supplemental adjusted joint multinomial models: source + centered year;
  source + centered year + serovar (top 10 by pooled frequency, all remaining
  or unknown serovars pooled). Standardize to the pooled comparison sample.
  Use the existing paired influence implementation and report both
  isolate-independent and serovar-clustered uncertainty when supported.
- Log convergence, Hessian conditioning, minimum fitted probability, common
  target distribution and allocation-identity checks. Numerical convergence
  alone is insufficient for accepting a fit.

## Sensitivity and interpretation

- Treat I as nonsusceptible (R or I vs S).
- Repeat without the additional assembly-quality thresholds.
- Bootstrap source contrasts under serovar block resampling (1,000 attempts)
  to assess dependence beyond the primary isolate-independent analysis.
- No drug, source or period will be selected because its OR reverses or its
  contrast is significant. Report the planned analyses even if their
  differences are small or precision is inadequate.
- Evaluate suitability for a food-chain AMR application, retaining the
  distinction between human health relevance and observed cross-sector
  sampling. The analysis does not establish animal-to-human transmission.

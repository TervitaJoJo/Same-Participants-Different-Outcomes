"""Stream one official bulk release, retaining only prespecified NARMS records."""

import csv
import hashlib
import io
import json
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen


BASE = Path(__file__).resolve().parent
RELEASE = "PDG000000002.4261"
URL = (
    "https://ftp.ncbi.nlm.nih.gov/pathogen/Results/Salmonella/"
    f"{RELEASE}/AMR/{RELEASE}.amr.metadata.tsv"
)
CATALOG_URL = (
    "https://ftp.ncbi.nlm.nih.gov/pathogen/Antimicrobial_resistance/"
    "Data/2025-12-03.1/ReferenceGeneCatalog.txt"
)
SOURCES = {"chicken breast", "ground turkey", "ground beef", "pork chop"}


class DigestReader(io.RawIOBase):
    def __init__(self, response):
        self.response = response
        self.digest = hashlib.sha256()
        self.count = 0

    def readable(self):
        return True

    def readinto(self, buffer):
        data = self.response.read(len(buffer))
        if not data:
            return 0
        self.digest.update(data)
        self.count += len(data)
        buffer[:len(data)] = data
        return len(data)


def main():
    data_dir = BASE / "data"
    data_dir.mkdir(exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    catalog = urlopen(CATALOG_URL, timeout=60).read()
    (data_dir / "ReferenceGeneCatalog_2025-12-03.1.tsv").write_bytes(catalog)
    plan_hash = hashlib.sha256((BASE / "ANALYSIS_PLAN.md").read_bytes()).hexdigest()
    counts = Counter()
    projects = Counter()
    source_counts = Counter()
    year_counts = Counter()
    output = data_dir / "narms_retail_source_records.csv"
    partial = output.with_suffix(".partial.csv")
    tick = time.monotonic()
    with urlopen(Request(URL, headers={"User-Agent": "paired-state-narms/1.0"}), timeout=120) as response:
        expected_bytes = int(response.headers["Content-Length"])
        last_modified = response.headers.get("Last-Modified")
        digest_reader = DigestReader(response)
        text = io.TextIOWrapper(io.BufferedReader(digest_reader, buffer_size=2**20), encoding="utf-8", newline="")
        reader = csv.DictReader(text, delimiter="\t")
        fields = ["label" if name == "#label" else name for name in reader.fieldnames]
        with partial.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in reader:
                counts["all_release_rows"] += 1
                if None in row or any(value is None for value in row.values()):
                    raise RuntimeError("Malformed source TSV record")
                is_narms = "narms" in row["project_name"].casefold() or row["bioproject_acc"] == "PRJNA292661"
                if is_narms:
                    counts["narms_labeled_rows"] += 1
                source = " ".join(row["isolation_source"].casefold().split())
                if is_narms and source in SOURCES:
                    row["label"] = row.pop("#label")
                    writer.writerow(row)
                    counts["retained_source_rows"] += 1
                    projects[row["bioproject_acc"]] += 1
                    source_counts[source] += 1
                    year_counts[row["collection_date"][:4]] += 1
                if time.monotonic() - tick >= 25:
                    print(json.dumps({"bytes_read": digest_reader.count, "expected_bytes": expected_bytes, **counts}), flush=True)
                    tick = time.monotonic()
        if digest_reader.count != expected_bytes:
            raise RuntimeError(f"Incomplete download: {digest_reader.count} != {expected_bytes}")
    partial.replace(output)
    manifest = {
        "started_utc": started,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "source_url": URL,
        "release": RELEASE,
        "last_modified": last_modified,
        "expected_source_bytes": expected_bytes,
        "retrieved_source_bytes": digest_reader.count,
        "source_sha256": digest_reader.digest.hexdigest(),
        "analysis_plan_sha256": plan_hash,
        "catalog_url": CATALOG_URL,
        "catalog_sha256": hashlib.sha256(catalog).hexdigest(),
        "counts": dict(counts),
        "source_counts_before_analytic_filters": dict(source_counts),
        "year_counts_before_analytic_filters": dict(sorted(year_counts.items())),
        "project_counts_before_analytic_filters": dict(projects),
        "retained_csv_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "completeness": "Entire official release streamed; byte count reconciled",
        "local_filter": "NARMS project label or PRJNA292661; four prespecified exact retail source labels",
    }
    (BASE / "retrieval_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2), flush=True)


if __name__ == "__main__":
    main()

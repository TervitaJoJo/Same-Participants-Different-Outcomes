"""Independently check all threshold counts, crude ORs and Holm adjustment."""

import json

import numpy as np
import pandas as pd

from scan_thresholds import OUT, TOTAL_FAMILY


def main():
    all_results = pd.read_csv(OUT / "cumulative_168_comparisons.csv")
    thresholds = pd.read_csv(OUT / "all_114_threshold_comparisons.csv")
    records = pd.read_csv(OUT / "all_threshold_paired_records.csv")
    candidates = pd.read_csv(OUT / "all_threshold_point_reversals.csv")
    assert len(all_results) == TOTAL_FAMILY == 168
    assert len(thresholds) == 114 and len(candidates) == 4
    assert not all_results[["comparison_family", "drug", "reference_source", "exposed_source"]].duplicated().any()
    assert not records[["drug", "biosample_acc"]].duplicated().any()
    assert (records.M <= records.S).all()
    assert (records.M == records.AST.eq("R").astype(int)).all()
    assert (records.S == records.AST.isin(["R", "I"]).astype(int)).all()
    max_error = 0.0
    for row in thresholds.itertuples():
        frame = records[records.drug.eq(row.drug) & records.source.isin([row.reference_source, row.exposed_source])]
        assert len(frame) == row.n
        events = {}
        for e, source in enumerate([row.reference_source, row.exposed_source]):
            part = frame[frame.source.eq(source)]
            for state, value in [("00", 0), ("V", 1), ("U", 2), ("11", 3)]:
                assert int(part.state.eq(value).sum()) == getattr(row, f"n{e}_{state}")
            for indicator in ["M", "S"]:
                events[(e, indicator)] = (int(part[indicator].sum()), len(part)-int(part[indicator].sum()))
        if row.status in {"ok", "sparse_binary_marginal_cell"}:
            logors = []
            for indicator in ["M", "S"]:
                a, b = events[(1, indicator)]
                c, d = events[(0, indicator)]
                oddsratio = a*d/(b*c)
                max_error = max(max_error, abs(oddsratio-getattr(row, f"OR_{indicator}")))
                assert abs(oddsratio-getattr(row, f"OR_{indicator}")) < 1e-10
                logors.append(np.log(oddsratio))
            assert abs(row.delta-(logors[1]-logors[0])) < 1e-10
            assert row.point_reversal == (logors[0]*logors[1] < 0)
    pvalues = all_results.delta_p.to_numpy()
    order = np.argsort(pvalues)
    corrected = np.minimum(1, np.maximum.accumulate(pvalues[order]*np.arange(TOTAL_FAMILY, 0, -1)))
    assert np.max(np.abs(corrected-all_results.delta_p_holm_cumulative.to_numpy()[order])) < 1e-12
    boot = pd.read_csv(OUT / "boot_denominators.csv")
    for row in boot.itertuples():
        assert row.attempts == row.successful+row.failed == 2000
        method = "isolate" if row.uncertainty.startswith("source") else "serovar"
        draws = pd.read_csv(OUT / f"c{row.candidate}_boot_{method}.csv")
        assert len(draws) == row.attempts
        assert draws.status.eq("ok").sum() == row.successful
        good = draws[draws.status.eq("ok")]
        assert good.C_U.abs().max() < 1e-10
        assert (good.C_V-good.delta).abs().max() < 1e-10
    checks = json.loads((OUT / "checks.json").read_text())
    assert len(checks) == 4
    assert max(r["independent_covariance_error"] for r in checks) < 1e-10
    report = dict(verification="passed", threshold_comparisons=114, cumulative_comparisons=168,
                  new_point_reversals=4, maximum_direct_OR_error=max_error,
                  bootstrap_logs_checked=len(boot), cumulative_Holm="independently_verified",
                  nested_structural_U="verified", unique_BioSample_within_drug="verified")
    (OUT / "verification.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

# Bounded exploratory search for food-source association reversals

Date: 2026-10-15. Written after inspecting AST availability and catalog
subclass labels, and after the primary tetracycline analysis, but before
calculating any new drug/source associations. This is an exploratory local
analysis plan, not a preregistration. The primary analysis remains unchanged.

## Fixed search family

Use the retained 6,161-record official NARMS Salmonella subset and pinned
2025-12-03.1 ReferenceGeneCatalog. Apply the primary USA, 2002-2023, completed
AMRFinderPlus, pinned database, BioSample deduplication/conflict and assembly
quality rules. Exclude AST I/ND/NS/missing; R=1 and S=0.

Nine drug indicators are fixed: amikacin, gentamicin, kanamycin, streptomycin,
chloramphenicol, azithromycin, tetracycline, sulfamethoxazole, sulfisoxazole.
For each, compare every unordered pair of the four exact normalized sources:
chicken breast, ground turkey, ground beef, pork chop. This gives 54 planned
comparisons, including those with no resistance or insufficient information.
Orient each pair according to that source order, with the earlier source as
reference. Do not select time windows, serovars, mappings or reference groups
according to their estimates.

S=1 denotes at least one complete core AMR catalog call with an exact
slash-delimited subclass token matching the drug name (uppercase).
Sulfamethoxazole and sulfisoxazole use the SULFONAMIDE subclass; these are
explicitly class-marker comparisons, not validated drug-specific predictions.
Other broad subclasses (e.g. AMINOGLYCOSIDE, MACROLIDE) are not silently
translated into drug-specific predictions. Beta-lactams, quinolones and the
combination trimethoprim-sulfamethoxazole are outside this bounded search
because their drug-specific mapping needs a separate validated algorithm.

Match exact allele and gene-family symbols. The core taxon restrictions follow
the primary analysis. A matching partial call without a complete call is
ambiguous and excluded. A symbol in the relevant catalog subset but outside
the taxon-eligible subset is also treated as ambiguous. Record every mapping,
observed call and excluded record count. The exploratory tetracycline mapping
uses subclass, while the primary analysis uses class; retain both definitions.

## Estimation and reporting

For each pair report all eight joint-state counts (00,V,U,11), sample size,
both crude ORs, kappa, disagreement and paired Delta=logOR(S)-logOR(M).
Calculate covariance-aware delta-method intervals directly from paired
binary outcomes. Empty discordant cells do not automatically invalidate
binary ORs. Mark zero marginal cells as nonestimable and marginal cells
below 5 as sparse. No continuity correction in the main screen.

Report three distinct criteria: opposite-signed log-OR point estimates;
a paired-difference interval excluding zero; and both individual OR intervals
lying on opposite sides of one. Apply Holm correction to all 54 planned
paired tests (nonestimable tests contribute p=1), and provide Bonferroni
simultaneous individual-OR intervals over 108 planned ORs. These screen
intervals assume independent isolates and do not settle clustering concerns.

## Candidate checks

Assess every point-reversal candidate, regardless of significance. Inspect
mapped genes, year and serovar composition. Resample paired isolates within
source (2,000 attempts) and serovar blocks (2,000 attempts), reporting all
failures. Retain descriptive estimates when full allocation is unsupported.
Use source+year standardized joint models when supported; use the existing
failure diagnostics. Treat year/serovar checks as sensitivity analyses.
Stronger claims require robustness to dependence and mapping review.

The complete search table accompanies any highlighted example. A discovered
example remains exploratory, and the original stable-direction tetracycline
application is retained. No manuscript claim is changed before verification.

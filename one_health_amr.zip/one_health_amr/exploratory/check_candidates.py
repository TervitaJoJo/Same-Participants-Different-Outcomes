"""Check every point-reversal candidate without changing the search family."""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from scipy.stats import norm, t

from scan_reversals import OUT, SOURCES, paired_estimates

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import paired_core as core

SEED = 2026101502
ATTEMPTS = 2000
METRICS = ["logOR_M", "logOR_S", "delta", "C_U", "C_V"]


def count_metrics(counts):
    totals = counts.sum(axis=1)
    if np.any(totals == 0):
        raise ValueError("empty_source")
    p = counts/totals[:, None]
    m, s = p[:, 2:].sum(axis=1), p[:, [1, 3]].sum(axis=1)
    if np.any((m <= 0) | (m >= 1) | (s <= 0) | (s >= 1)):
        raise ValueError("zero_binary_marginal_cell")
    lm, ls = logit(m[1])-logit(m[0]), logit(s[1])-logit(s[0])
    values = np.r_[lm, ls, ls-lm, np.nan, np.nan]
    # Allocation uses the actual intermediate risks. Empty U/V cells alone
    # do not make either the binary OR or the allocation point value undefined.
    if (p[:, [0, 3]] > 0).all():
        values[3:] = core.joint_metrics(p.ravel())[9:11]
        assert abs(values[2]-values[3:].sum()) < 1e-10
    return values


def bootstrap(group, method, seed):
    rng = np.random.default_rng(seed)
    counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
    if method == "source_stratified_isolate":
        draws = np.stack([rng.multinomial(int(c.sum()), c/c.sum(), size=ATTEMPTS) for c in counts], axis=1)
    else:
        serovars = sorted(group.serovar_clean.unique())
        positions = {v: j for j, v in enumerate(serovars)}
        cube = np.zeros((len(serovars), 2, 4), dtype=int)
        for row in group.itertuples():
            cube[positions[row.serovar_clean], row.E, row.state] += 1
        draws = np.array([cube[rng.integers(0, len(cube), size=len(cube))].sum(axis=0) for _ in range(ATTEMPTS)])
    rows = []
    for rep, counts in enumerate(draws):
        row = dict(replicate=rep, status="ok", full_eight_cells_positive=bool((counts > 0).all()))
        try:
            row.update(zip(METRICS, count_metrics(counts)))
        except ValueError as exc:
            row["status"] = str(exc)
        rows.append(row)
    return pd.DataFrame(rows)


def adjusted_binary(group):
    group = group.copy()
    group["year_c"] = group.year-group.year.mean()
    values, influences, diagnostics = [], [], []
    for indicator in ["M", "S"]:
        v, psi, diagnostic = core.binary_marginal(group, group[indicator], "E + year_c")
        values.append(v[3])
        influences.append(psi[:, 3])
        diagnostics.append(diagnostic)
    values = np.array([*values, values[1]-values[0]])
    influence = np.column_stack([*influences, influences[1]-influences[0]])
    results = []
    for method in ["isolate_influence", "serovar_cluster_influence"]:
        frame = group.assign(strata=1, cluster=np.arange(len(group)))
        if method == "serovar_cluster_influence":
            frame["cluster"] = pd.factorize(group.serovar_clean)[0]
        covariance, df = core.cov_cluster(influence, frame)
        critical = t.ppf(.975, df) if method.startswith("serovar") else norm.ppf(.975)
        for j, metric in enumerate(METRICS[:3]):
            se = np.sqrt(covariance[j, j])
            results.append(dict(metric=metric, estimate=values[j], low=values[j]-critical*se,
                                high=values[j]+critical*se, uncertainty=method, df=df,
                                model="paired_binary_GLM_source_plus_linear_year",
                                target="pooled_candidate_comparison_sample"))
    return results, diagnostics


def verify_count_covariance(group, result, influence):
    expected = np.zeros((2, 2))
    for _, part in group.groupby("E"):
        y = part[["M", "S"]].to_numpy(float)
        p = y.mean(axis=0)
        pm, ps = p
        expected[0, 0] += 1/(len(y)*pm*(1-pm))
        expected[1, 1] += 1/(len(y)*ps*(1-ps))
        cov = (np.mean(y[:, 0]*y[:, 1])-pm*ps)/(len(y)*pm*(1-pm)*ps*(1-ps))
        expected[0, 1] += cov
        expected[1, 0] += cov
    assert np.max(np.abs(expected-influence.T@influence)) < 1e-10
    assert np.max(np.abs(influence.sum(axis=0))) < 1e-10
    reverse = group.copy()
    reverse["E"] = 1-reverse.E
    rev, _ = paired_estimates(reverse)
    assert abs(rev["delta"]+result["delta"]) < 1e-10
    assert abs(rev["delta_se"]-result["delta_se"]) < 1e-10
    swap = group.copy()
    swap[["M", "S"]] = swap[["S", "M"]].to_numpy()
    sw, _ = paired_estimates(swap)
    assert abs(sw["delta"]+result["delta"]) < 1e-10
    return float(np.max(np.abs(expected-influence.T@influence)))


def main():
    candidates = pd.read_csv(OUT / "all_point_reversals.csv")
    all_records = pd.read_csv(OUT / "all_drug_paired_records.csv", keep_default_na=False)
    estimates, denominators, verifications = [], [], []
    for j, candidate in enumerate(candidates.itertuples()):
        group = all_records[all_records.drug.eq(candidate.drug) & all_records.source.isin([candidate.reference_source, candidate.exposed_source])].copy().reset_index(drop=True)
        group["E"] = group.source.eq(candidate.exposed_source).astype(int)
        label = dict(drug=candidate.drug, reference_source=candidate.reference_source,
                     exposed_source=candidate.exposed_source, n=len(group))
        point, influence = paired_estimates(group)
        error = verify_count_covariance(group, point, influence)
        counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
        label["primary_full_state_screen_passed"] = bool((counts > 0).all())
        point_values = count_metrics(counts)
        key = f"candidate_{j+1}"
        group.to_csv(OUT / f"{key}_paired_records.csv", index=False)
        group.groupby(["source", "year", "M", "S"]).size().rename("n").reset_index().to_csv(OUT / f"{key}_year_states.csv", index=False)
        group.groupby(["source", "serovar_clean", "M", "S"]).size().rename("n").reset_index().to_csv(OUT / f"{key}_serovar_states.csv", index=False)
        group.groupby(["source", "mapped_genes"], dropna=False).size().rename("n").reset_index().to_csv(OUT / f"{key}_gene_counts.csv", index=False)
        for k, method in enumerate(["source_stratified_isolate", "serovar_block"]):
            seed = SEED+10*j+k
            draws = bootstrap(group, method, seed)
            draws.to_csv(OUT / f"{key}_bootstrap_{method}.csv", index=False)
            good = draws[draws.status.eq("ok")]
            full = int(draws.full_eight_cells_positive.sum())
            denominators.append(dict(label, method=method, seed=seed, attempts=ATTEMPTS,
                                     successful=len(good), failed=ATTEMPTS-len(good),
                                     full_eight_cells_positive=full,
                                     failure_counts=json.dumps(draws.loc[~draws.status.eq("ok"), "status"].value_counts().to_dict())))
            for idx, metric in enumerate(METRICS):
                vals = good[metric].dropna()
                low, high = vals.quantile([.025, .975]) if len(vals) > 1 else [np.nan, np.nan]
                estimates.append(dict(label, metric=metric, estimate=point_values[idx],
                                      low=low, high=high, uncertainty=method,
                                      model="empirical_source_only", successful=len(vals), attempts=ATTEMPTS,
                                      interval_scope="exploratory_empirical_support_bootstrap"))
        try:
            adjusted, diagnostics = adjusted_binary(group)
            estimates.extend(dict(label, **v) for v in adjusted)
            adjustment_status = "ok"
        except (ValueError, AssertionError, np.linalg.LinAlgError) as exc:
            diagnostics = [dict(error=str(exc))]
            adjustment_status = "failed"
        verifications.append(dict(label, independent_covariance_error=error,
                                  allocation_identity_error=float(abs(point_values[2]-sum(point_values[3:]))),
                                  source_relabeling="passed", outcome_swap="passed",
                                  full_state_inference_status="supported" if (counts > 0).all() else "zero_required_source_state_cell",
                                  year_adjusted_binary_status=adjustment_status,
                                  adjusted_diagnostics=diagnostics))
    pd.DataFrame(estimates).to_csv(OUT / "candidate_robustness_estimates.csv", index=False)
    pd.DataFrame(denominators).to_csv(OUT / "candidate_bootstrap_denominators.csv", index=False)
    (OUT / "candidate_verification.json").write_text(json.dumps(verifications, indent=2)+"\n", encoding="utf-8")
    print(pd.DataFrame(estimates).to_string(index=False))
    print(pd.DataFrame(denominators).to_string(index=False))
    print(json.dumps(verifications, indent=2))


if __name__ == "__main__":
    main()

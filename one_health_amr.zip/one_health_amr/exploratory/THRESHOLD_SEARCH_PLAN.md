# Additional exploratory family: submitted R versus R-or-I classifications

2026-10-15. Written after the previous 54-comparison genotype-marker search,
which found one uncertain kanamycin point reversal, and after inspecting only
AST category availability for the new family. No source associations under
the new paired threshold definitions have yet been calculated. This is a
post hoc exploratory extension, not preregistration or independent validation.

## Question and endpoints

Do source associations cross the null when the very same isolates are
classified by submitted resistant (R) versus non-susceptible (R or I) labels?

M=1 for R, M=0 for S or I. S=1 for R or I, S=0 for S. Include only isolates
whose submitted AST is exactly R, I or S for the drug; exclude NS, missing,
ND, conflicting or untested labels. Do not infer an R status for NS records.
The submitted I label is preserved as a distinct classification, not claimed
to be clinical resistance. No MIC reclassification or modern harmonized
breakpoint is inferred from these categorical metadata. The two binary
endpoints represent deliberately different surveillance thresholds.

With these nested endpoints, U (M=1,S=0) is structurally impossible.
Three-state support, paired binary inference and finite marginal probabilities
must be evaluated accordingly. The primary unconstrained four-state screen
is not an appropriate estimability criterion for this nested analysis.
The symmetric allocation has C_U=0 and C_V=Delta when defined.

## Fixed data and comparison family

Use the same retained 6,161 NARMS food records, USA, intended years 2002-2023,
AMRFinderPlus completed, pinned catalog, same deterministic deduplication and
assembly quality filters. Keep these rules for comparability even though
genomic calls do not define the new endpoints. Deduplication conflicts use
source, submitted drug AST, year and serovar; record the full exclusion flow.

Include every drug observed in the source metadata: amikacin,
amoxicillin-clavulanic acid, ampicillin, azithromycin, cefoxitin, ceftiofur,
ceftriaxone, chloramphenicol, ciprofloxacin, colistin, gentamicin, kanamycin,
meropenem, nalidixic acid, streptomycin, sulfamethoxazole, sulfisoxazole,
tetracycline and trimethoprim-sulfamethoxazole. No-drug-intermediate and
no-resistant-event cases remain in the denominator and output.

Compare all six unordered pairs of chicken breast, ground turkey, ground
beef and pork chop, oriented by that fixed order. Nineteen drugs times six
source pairs gives 114 new comparisons. No year window or serovar subset
will be chosen by an association estimate.

## Inference, multiplicity and candidate checks

Reuse paired empirical influence covariance and finite binary-OR checks.
Report all 114 results and failures. Combine the 114 new tests with the
54 earlier exploratory tests for a cumulative 168-comparison Holm correction;
nonestimable tests have p=1. Recompute Bonferroni simultaneous individual-OR
intervals over the cumulative 336 ORs. Retain the earlier family result as a
historical output, but do not reset the multiplicity denominator when
describing the expanded search. These adjustments do not turn adaptive
exploration into a prospectively confirmatory analysis.

For every point-reversal candidate, report both OR intervals, the paired
difference, joint counts, kappa and missingness. Reuse 2,000 paired
source-stratified and 2,000 serovar-block bootstrap attempts; report every
failure. Check year-adjusted paired binary models standardized to the pooled
sample, with isolate and serovar-clustered uncertainty. All candidate
intervals are exploratory sensitivity analyses, not independent replication.
If instability is evident, add and report a prespecified full-candidate
leave-one-serovar-out diagnostic, not selective exclusions.

No manuscript content is changed by running this search. Any new example
must be labelled threshold-based and exploratory; the original tetracycline
application and all earlier results remain available.

"""Explore all submitted R versus R-or-I source contrasts on a common sample."""

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

from scan_reversals import BASE, MISSING, SOURCES, ast, load_inputs, paired_estimates

OUT = Path(__file__).resolve().parent / "threshold_results"
DRUGS = ["amikacin", "amoxicillin-clavulanic acid", "ampicillin", "azithromycin",
         "cefoxitin", "ceftiofur", "ceftriaxone", "chloramphenicol", "ciprofloxacin",
         "colistin", "gentamicin", "kanamycin", "meropenem", "nalidixic acid",
         "streptomycin", "sulfamethoxazole", "sulfisoxazole", "tetracycline",
         "trimethoprim-sulfamethoxazole"]
NEW_FAMILY = len(DRUGS)*6
TOTAL_FAMILY = NEW_FAMILY+54


def prepare(raw, drug):
    frame = raw.copy()
    frame["AST"] = frame.AST_phenotypes.map(lambda v: ast(v, drug))
    flow = []

    def retain(mask, stage):
        nonlocal frame
        before = len(frame)
        frame = frame.loc[mask].copy()
        flow.append(dict(drug=drug, stage=stage, input_rows=before,
                         excluded_rows=before-len(frame), remaining_rows=len(frame)))

    retain(frame.geo_loc_name.str.split(":").str[0].eq("USA"), "USA")
    retain(frame.year.between(2002, 2023), "Years 2002-2023")
    retain(frame.source.isin(SOURCES), "Four food sources")
    retain(~frame.biosample_acc.isin(MISSING), "BioSample present")
    retain(frame.amrfinder_applied.eq("1"), "AMRFinder completed")
    retain(frame.refgene_db_version.eq("2025-12-03.1"), "Pinned catalog")
    conflict = frame.groupby("biosample_acc")[["source", "AST", "year", "serovar_clean"]].nunique().gt(1).any(axis=1)
    retain(~frame.biosample_acc.isin(conflict[conflict].index), "No conflicting BioSample")
    before = len(frame)
    frame = frame.sort_values(["n50", "contigs", "target_acc"], ascending=[False, True, True]).drop_duplicates("biosample_acc")
    flow.append(dict(drug=drug, stage="Deduplicate", input_rows=before,
                     excluded_rows=before-len(frame), remaining_rows=len(frame)))
    retain(frame.AST.isin(["R", "I", "S"]), "Common sample: AST R, I or S")
    retain(frame.genome_length.between(4_000_000, 6_000_000) & frame.contigs.le(500) & frame.n50.ge(20_000), "Assembly QC")
    frame["M"] = frame.AST.eq("R").astype(int)
    frame["S"] = frame.AST.isin(["R", "I"]).astype(int)
    frame["state"] = 2*frame.M+frame.S
    frame["year"] = frame.year.astype(int)
    frame["drug"] = drug
    assert not frame.state.eq(2).any()
    return frame, flow


def simultaneous_intervals(row):
    critical = norm.ppf(1-.05/(4*TOTAL_FAMILY))
    for indicator in ["M", "S"]:
        sd = (np.log(row[f"OR_{indicator}_high_95"])-row[f"logOR_{indicator}"])/norm.ppf(.975)
        row[f"OR_{indicator}_low_cumulative"] = np.exp(row[f"logOR_{indicator}"]-critical*sd)
        row[f"OR_{indicator}_high_cumulative"] = np.exp(row[f"logOR_{indicator}"]+critical*sd)
    row["both_opposite_cumulative"] = bool(row["point_reversal"] and all(
        row[f"OR_{v}_low_cumulative"] > 1 or row[f"OR_{v}_high_cumulative"] < 1 for v in ["M", "S"]))
    return row


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    raw, _ = load_inputs()
    rows, flows, analytic = [], [], []
    for drug in DRUGS:
        frame, flow = prepare(raw, drug)
        flows.extend(flow)
        analytic.append(frame)
        for reference, source in itertools.combinations(SOURCES, 2):
            group = frame[frame.source.isin([reference, source])].copy().reset_index(drop=True)
            group["E"] = group.source.eq(source).astype(int)
            counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
            row = dict(drug=drug, comparison_family="R_vs_R_or_I", reference_source=reference,
                       exposed_source=source, n=len(group), status="ok", delta_p=1.0,
                       point_reversal=False, delta_ci_excludes_zero=False,
                       both_opposite_95=False, both_opposite_family=False,
                       both_opposite_cumulative=False)
            for e in [0, 1]:
                for j, state in enumerate(["00", "V", "U", "11"]):
                    row[f"n{e}_{state}"] = int(counts[e, j])
            if len(group):
                pooled = counts.sum(axis=0)/counts.sum()
                pm, ps = pooled[2:].sum(), pooled[[1, 3]].sum()
                pe = pm*ps+(1-pm)*(1-ps)
                row.update(kappa=(pooled[[0, 3]].sum()-pe)/(1-pe) if pe < 1 else np.nan,
                           disagreement=pooled[[1, 2]].sum())
            try:
                result, _ = paired_estimates(group, family_size=TOTAL_FAMILY)
                row.update(result)
                row = simultaneous_intervals(row)
                if result["minimum_binary_cell"] < 5:
                    row["status"] = "sparse_binary_marginal_cell"
            except ValueError as exc:
                row["status"] = str(exc)
            rows.append(row)
    results = pd.DataFrame(rows)
    earlier = pd.read_csv(Path(__file__).resolve().parent / "results/all_54_comparisons.csv")
    earlier["comparison_family"] = "phenotype_vs_catalog_marker"
    earlier = pd.DataFrame([simultaneous_intervals(row) if row["status"] in {"ok", "sparse_binary_marginal_cell"}
                            else dict(row, both_opposite_cumulative=False) for row in earlier.to_dict("records")])
    combined = pd.concat([earlier, results], ignore_index=True)
    combined["delta_p_holm_cumulative"] = multipletests(combined.delta_p, method="holm")[1]
    combined["delta_holm_cumulative_significant"] = combined.delta_p_holm_cumulative.lt(.05)
    assert len(combined) == TOTAL_FAMILY
    combined.to_csv(OUT / "cumulative_168_comparisons.csv", index=False)
    combined.iloc[54:].to_csv(OUT / "all_114_threshold_comparisons.csv", index=False)
    combined.iloc[54:].loc[combined.iloc[54:].point_reversal].to_csv(OUT / "all_threshold_point_reversals.csv", index=False)
    pd.DataFrame(flows).to_csv(OUT / "threshold_sample_flows.csv", index=False)
    columns = ["drug", "biosample_acc", "target_acc", "source", "year", "serovar_clean", "AST", "M", "S", "state"]
    pd.concat(analytic)[columns].to_csv(OUT / "all_threshold_paired_records.csv", index=False)
    manifest = dict(new_planned_comparisons=NEW_FAMILY, cumulative_planned_comparisons=TOTAL_FAMILY,
                    status_counts=results.status.value_counts().to_dict(),
                    new_point_reversals=int(results.point_reversal.sum()),
                    new_opposite_individual_95=int(results.both_opposite_95.sum()),
                    new_opposite_individual_cumulative=int(results.both_opposite_cumulative.sum()),
                    new_reversals_with_cumulative_holm_difference=int((combined.iloc[54:].point_reversal & combined.iloc[54:].delta_holm_cumulative_significant).sum()))
    for name, path in [("plan", Path(__file__).with_name("THRESHOLD_SEARCH_PLAN.md")),
                       ("source_records", BASE / "data/narms_retail_source_records.csv")]:
        manifest[name+"_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT / "threshold_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    cols = ["drug", "reference_source", "exposed_source", "n", "OR_M", "OR_S", "delta", "delta_low", "delta_high", "delta_p_holm_cumulative", "both_opposite_95", "both_opposite_cumulative", "status"]
    print(combined.loc[combined.point_reversal, cols].to_string(index=False))


if __name__ == "__main__":
    main()

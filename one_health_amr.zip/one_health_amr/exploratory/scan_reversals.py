"""Run the bounded, fully reported exploratory drug/source search."""

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

BASE = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "results"
SOURCES = ["chicken breast", "ground turkey", "ground beef", "pork chop"]
DRUGS = {
    "amikacin": "AMIKACIN", "gentamicin": "GENTAMICIN",
    "kanamycin": "KANAMYCIN", "streptomycin": "STREPTOMYCIN",
    "chloramphenicol": "CHLORAMPHENICOL", "azithromycin": "AZITHROMYCIN",
    "tetracycline": "TETRACYCLINE", "sulfamethoxazole": "SULFONAMIDE",
    "sulfisoxazole": "SULFONAMIDE",
}
MISSING = {"", "NULL", "missing", "not provided", "not collected", "N/A", "NA"}
FAMILY = len(DRUGS) * 6


def load_inputs():
    raw = pd.read_csv(BASE / "data/narms_retail_source_records.csv", dtype=str, keep_default_na=False)
    catalog = pd.read_csv(BASE / "data/ReferenceGeneCatalog_2025-12-03.1.tsv", sep="\t", dtype=str, keep_default_na=False)
    raw["source"] = raw.isolation_source.str.casefold().str.split().str.join(" ")
    raw["year"] = pd.to_numeric(raw.collection_date.str.extract(r"^(\d{4})", expand=False), errors="coerce")
    raw["serovar_clean"] = raw.serovar.where(~raw.serovar.isin(MISSING), "Unknown")
    raw["genome_length"] = pd.to_numeric(raw.asm_stats_length_bp, errors="coerce")
    raw["contigs"] = pd.to_numeric(raw.asm_stats_n_contig, errors="coerce")
    raw["n50"] = pd.to_numeric(raw.asm_stats_contig_n50, errors="coerce")
    return raw, catalog


def mapping_for(catalog, token):
    relevant = catalog[catalog.scope.eq("core") & catalog.type.eq("AMR")
                       & catalog.subclass.str.split("/").map(lambda v: token in v)].copy()
    eligible = relevant[(relevant.whitelisted_taxa.eq("") | relevant.whitelisted_taxa.str.contains("Salmonella", regex=False))
                        & ~relevant.blacklisted_taxa.str.contains("Salmonella", regex=False)]
    keys = lambda c: (set(c.allele) | set(c.gene_family)) - {""}
    return eligible, keys(eligible), keys(relevant)


def genomic(value, mapping, relevant):
    complete, ambiguous = set(), set()
    for entry in value.split(","):
        symbol, _, flag = entry.strip().partition("=")
        if symbol in mapping and "PARTIAL" not in flag:
            complete.add(symbol)
        elif symbol in relevant:
            ambiguous.add(symbol)
    return (1 if complete else -1 if ambiguous else 0,
            ";".join(sorted(complete)), ";".join(sorted(ambiguous)))


def ast(value, drug):
    found = {item.rsplit("=", 1)[1] for item in value.split(",")
             if "=" in item and item.rsplit("=", 1)[0].casefold() == drug}
    return next(iter(found)) if len(found) == 1 else "conflict" if found else "untested"


def prepare(raw, catalog, drug, token):
    eligible, mapping, relevant = mapping_for(catalog, token)
    eligible.assign(drug=drug).to_csv(OUT / f"mapping_{drug}.csv", index=False)
    frame = raw.copy()
    frame[["S", "mapped_genes", "ambiguous_genes"]] = pd.DataFrame(
        [genomic(v, mapping, relevant) for v in frame.AMR_genotypes], index=frame.index)
    frame["AST"] = frame.AST_phenotypes.map(lambda v: ast(v, drug))
    flow = []

    def retain(mask, stage):
        nonlocal frame
        before = len(frame)
        frame = frame.loc[mask].copy()
        flow.append(dict(drug=drug, stage=stage, input_rows=before,
                         excluded_rows=before-len(frame), remaining_rows=len(frame)))

    retain(frame.geo_loc_name.str.split(":").str[0].eq("USA"), "USA")
    retain(frame.year.between(2002, 2023), "Years 2002-2023")
    retain(frame.source.isin(SOURCES), "Four food sources")
    retain(~frame.biosample_acc.isin(MISSING), "BioSample present")
    retain(frame.amrfinder_applied.eq("1"), "AMRFinder completed")
    retain(frame.refgene_db_version.eq("2025-12-03.1"), "Pinned catalog")
    conflict = frame.groupby("biosample_acc")[["source", "AST", "S", "year", "serovar_clean"]].nunique().gt(1).any(axis=1)
    retain(~frame.biosample_acc.isin(conflict[conflict].index), "No conflicting BioSample")
    before = len(frame)
    frame = frame.sort_values(["n50", "contigs", "target_acc"], ascending=[False, True, True]).drop_duplicates("biosample_acc")
    flow.append(dict(drug=drug, stage="Deduplicate", input_rows=before, excluded_rows=before-len(frame), remaining_rows=len(frame)))
    retain(frame.S.ge(0), "Unambiguous genomic indicator")
    retain(frame.AST.isin(["R", "S"]), "AST R or S")
    retain(frame.genome_length.between(4_000_000, 6_000_000) & frame.contigs.le(500) & frame.n50.ge(20_000), "Assembly QC")
    frame["M"] = frame.AST.eq("R").astype(int)
    frame["S"] = frame.S.astype(int)
    frame["state"] = 2*frame.M+frame.S
    frame["year"] = frame.year.astype(int)
    frame["drug"] = drug
    return frame, flow


def paired_estimates(group, family_size=FAMILY):
    """Crude log ORs and their paired empirical influence covariance."""
    n = len(group)
    effects = np.zeros(2)
    influence = np.zeros((n, 2))
    marginal_cells = []
    for e, sign in [(0, -1), (1, 1)]:
        ix = np.flatnonzero(group.E.to_numpy() == e)
        if not len(ix):
            raise ValueError("empty_source")
        y = group.iloc[ix][["M", "S"]].to_numpy(float)
        p = y.mean(axis=0)
        marginal_cells.extend(np.r_[y.sum(axis=0), len(y)-y.sum(axis=0)])
        if np.any((p == 0) | (p == 1)):
            raise ValueError("zero_binary_marginal_cell")
        effects += sign * logit(p)
        influence[ix] = sign * (y-p)/(len(ix)*p*(1-p))
    covariance = influence.T @ influence
    delta = effects[1]-effects[0]
    variance = covariance[0, 0]+covariance[1, 1]-2*covariance[0, 1]
    se = np.sqrt(np.maximum(variance, 0))
    pvalue = float(2*norm.sf(abs(delta)/se)) if se > 0 else 1.0 if delta == 0 else 0.0
    result = dict(logOR_M=effects[0], logOR_S=effects[1], delta=delta,
                  delta_se=se, delta_low=delta-norm.ppf(.975)*se,
                  delta_high=delta+norm.ppf(.975)*se, delta_p=pvalue,
                  paired_covariance=covariance[0, 1],
                  minimum_binary_cell=int(min(marginal_cells)),
                  point_reversal=bool(effects[0]*effects[1] < 0),
                  delta_ci_excludes_zero=bool(abs(delta) > norm.ppf(.975)*se))
    for j, indicator in enumerate(["M", "S"]):
        sd = np.sqrt(covariance[j, j])
        for label, critical in [("95", norm.ppf(.975)), ("family", norm.ppf(1-.05/(4*family_size)))]:
            result[f"OR_{indicator}"] = np.exp(effects[j])
            result[f"OR_{indicator}_low_{label}"] = np.exp(effects[j]-critical*sd)
            result[f"OR_{indicator}_high_{label}"] = np.exp(effects[j]+critical*sd)
    result["both_opposite_95"] = bool(result["point_reversal"] and all(
        result[f"OR_{v}_low_95"] > 1 or result[f"OR_{v}_high_95"] < 1 for v in ["M", "S"]))
    result["both_opposite_family"] = bool(result["point_reversal"] and all(
        result[f"OR_{v}_low_family"] > 1 or result[f"OR_{v}_high_family"] < 1 for v in ["M", "S"]))
    return result, influence


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    raw, catalog = load_inputs()
    rows, flows, analytic = [], [], []
    for drug, token in DRUGS.items():
        frame, flow = prepare(raw, catalog, drug, token)
        flows.extend(flow)
        analytic.append(frame)
        for reference, source in itertools.combinations(SOURCES, 2):
            group = frame[frame.source.isin([reference, source])].copy().reset_index(drop=True)
            group["E"] = group.source.eq(source).astype(int)
            counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
            row = dict(drug=drug, genomic_subclass=token, reference_source=reference,
                       exposed_source=source, n=len(group), status="ok", delta_p=1.0,
                       point_reversal=False, delta_ci_excludes_zero=False,
                       both_opposite_95=False, both_opposite_family=False)
            for e in [0, 1]:
                for j, state in enumerate(["00", "V", "U", "11"]):
                    row[f"n{e}_{state}"] = int(counts[e, j])
            if len(group):
                pooled = counts.sum(axis=0)/counts.sum()
                pm, ps = pooled[2:].sum(), pooled[[1, 3]].sum()
                pe = pm*ps+(1-pm)*(1-ps)
                row.update(kappa=(pooled[[0, 3]].sum()-pe)/(1-pe) if pe < 1 else np.nan,
                           disagreement=pooled[[1, 2]].sum())
            try:
                result, _ = paired_estimates(group)
                row.update(result)
                if result["minimum_binary_cell"] < 5:
                    row["status"] = "sparse_binary_marginal_cell"
            except ValueError as exc:
                row["status"] = str(exc)
            rows.append(row)
    results = pd.DataFrame(rows)
    results["delta_p_holm"] = multipletests(results.delta_p, method="holm")[1]
    results["delta_holm_significant"] = results.delta_p_holm.lt(.05)
    results.to_csv(OUT / "all_54_comparisons.csv", index=False)
    results[results.point_reversal].to_csv(OUT / "all_point_reversals.csv", index=False)
    pd.DataFrame(flows).to_csv(OUT / "all_drug_sample_flows.csv", index=False)
    columns = ["drug", "biosample_acc", "target_acc", "source", "year", "serovar_clean", "AST", "M", "S", "state", "mapped_genes", "ambiguous_genes"]
    pd.concat(analytic)[columns].to_csv(OUT / "all_drug_paired_records.csv", index=False)
    manifest = dict(planned_comparisons=FAMILY, calculated=len(results),
                    status_counts=results.status.value_counts().to_dict(),
                    point_reversals=int(results.point_reversal.sum()),
                    opposite_individual_95=int(results.both_opposite_95.sum()),
                    opposite_individual_family=int(results.both_opposite_family.sum()),
                    reversals_with_holm_paired_difference=int((results.point_reversal & results.delta_holm_significant).sum()))
    for name, path in [("plan", Path(__file__).with_name("EXPLORATORY_PLAN.md")),
                       ("source_records", BASE / "data/narms_retail_source_records.csv"),
                       ("catalog", BASE / "data/ReferenceGeneCatalog_2025-12-03.1.tsv")]:
        manifest[name+"_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT / "scan_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    cols = ["drug", "reference_source", "exposed_source", "n", "OR_M", "OR_S", "delta", "delta_low", "delta_high", "delta_p_holm", "both_opposite_95", "both_opposite_family", "status"]
    print(results.loc[results.point_reversal, cols].to_string(index=False))


if __name__ == "__main__":
    main()

"""Audit every reversal from the fixed R versus R-or-I exploratory family."""

import json

import numpy as np
import pandas as pd
from scipy.stats import norm, t

from check_candidates import (
    ATTEMPTS, METRICS, adjusted_binary, bootstrap, core, count_metrics,
    verify_count_covariance,
)
from scan_reversals import paired_estimates
from scan_thresholds import OUT, TOTAL_FAMILY

SEED = 2026101510


def clustered_crude(group, point, influence):
    frame = group.assign(strata=1, cluster=pd.factorize(group.serovar_clean)[0])
    psi = np.column_stack([influence, influence[:, 1]-influence[:, 0]])
    covariance, df = core.cov_cluster(psi, frame)
    critical = t.ppf(.975, df)
    rows = []
    for j, metric in enumerate(METRICS[:3]):
        se = np.sqrt(covariance[j, j])
        estimate = point[metric]
        rows.append(dict(metric=metric, estimate=estimate, low=estimate-critical*se,
                         high=estimate+critical*se, uncertainty="serovar_cluster_influence",
                         model="empirical_source_only", df=df))
    return rows


def year_categorical(group):
    values, influences, diagnostics = [], [], []
    for indicator in ["M", "S"]:
        v, psi, diagnostic = core.binary_marginal(group, group[indicator], "E + C(year)")
        values.append(v[3])
        influences.append(psi[:, 3])
        diagnostics.append(diagnostic)
    values = np.array([*values, values[1]-values[0]])
    psi = np.column_stack([*influences, influences[1]-influences[0]])
    rows = []
    for uncertainty in ["isolate_influence", "serovar_cluster_influence"]:
        frame = group.assign(strata=1, cluster=np.arange(len(group)))
        if uncertainty.startswith("serovar"):
            frame["cluster"] = pd.factorize(group.serovar_clean)[0]
        covariance, df = core.cov_cluster(psi, frame)
        critical = t.ppf(.975, df) if uncertainty.startswith("serovar") else norm.ppf(.975)
        for j, metric in enumerate(METRICS[:3]):
            se = np.sqrt(covariance[j, j])
            rows.append(dict(metric=metric, estimate=values[j], low=values[j]-critical*se,
                             high=values[j]+critical*se, uncertainty=uncertainty, df=df,
                             model="paired_binary_GLM_source_plus_categorical_year",
                             target="pooled_candidate_comparison_sample"))
    return rows, diagnostics


def main():
    candidates = pd.read_csv(OUT / "all_threshold_point_reversals.csv")
    records = pd.read_csv(OUT / "all_threshold_paired_records.csv", keep_default_na=False)
    estimates, denominators, verifications, sensitivity, composition = [], [], [], [], []
    for j, candidate in enumerate(candidates.itertuples()):
        group = records[records.drug.eq(candidate.drug) & records.source.isin(
            [candidate.reference_source, candidate.exposed_source])].copy().reset_index(drop=True)
        group["E"] = group.source.eq(candidate.exposed_source).astype(int)
        label = dict(candidate=j+1, drug=candidate.drug, reference_source=candidate.reference_source,
                     exposed_source=candidate.exposed_source, n=len(group))
        point, influence = paired_estimates(group, family_size=TOTAL_FAMILY)
        error = verify_count_covariance(group, point, influence)
        counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
        assert not counts[:, 2].any()
        values = count_metrics(counts)
        assert abs(values[3]) < 1e-12
        assert abs(values[4]-values[2]) < 1e-12
        group.to_csv(OUT / f"c{j+1}_records.csv", index=False)
        for dimension in ["year", "serovar_clean"]:
            table = group.groupby(["source", dimension, "AST"]).size().rename("count").reset_index()
            composition.extend(dict(label, dimension=dimension, category=str(row[dimension]),
                                    source=row["source"], AST=row["AST"], count=row["count"])
                               for row in table.to_dict("records"))
        estimates.extend(dict(label, **row) for row in clustered_crude(group, point, influence))
        for k, method in enumerate(["source_stratified_isolate", "serovar_block"]):
            draws = bootstrap(group, method, SEED+10*j+k)
            # The absent U cell is structural for the nested definitions.
            draws.rename(columns={"full_eight_cells_positive": "unconstrained_four_state_screen_passed"}, inplace=True)
            short_method = "isolate" if method.startswith("source") else "serovar"
            draws.to_csv(OUT / f"c{j+1}_boot_{short_method}.csv", index=False)
            good = draws[draws.status.eq("ok")]
            denominators.append(dict(label, uncertainty=method, seed=SEED+10*j+k,
                                     attempts=ATTEMPTS, successful=len(good), failed=ATTEMPTS-len(good),
                                     failure_counts=json.dumps(draws.loc[~draws.status.eq("ok"), "status"].value_counts().to_dict()),
                                     structural_U_zero=True))
            for idx, metric in enumerate(METRICS):
                valid = good[metric].dropna()
                low, high = valid.quantile([.025, .975]) if len(valid) > 1 else [np.nan, np.nan]
                estimates.append(dict(label, metric=metric, estimate=values[idx], low=low,
                                      high=high, uncertainty=method, model="empirical_source_only",
                                      successful=len(valid), attempts=ATTEMPTS))
        diagnostics = {}
        for model_name, function in [("linear_year", adjusted_binary), ("categorical_year", year_categorical)]:
            try:
                rows, diagnostic = function(group)
                estimates.extend(dict(label, **row) for row in rows)
                diagnostics[model_name] = dict(status="ok", diagnostics=diagnostic)
            except (ValueError, AssertionError, np.linalg.LinAlgError, FloatingPointError) as exc:
                diagnostics[model_name] = dict(status="failed", reason=str(exc))
        for omitted in sorted(group.serovar_clean.unique()):
            reduced = group.loc[~group.serovar_clean.eq(omitted)].reset_index(drop=True)
            row = dict(label, omitted_serovar=omitted, remaining_n=len(reduced), status="ok")
            try:
                result, _ = paired_estimates(reduced, family_size=TOTAL_FAMILY)
                row.update({key: result[key] for key in ["OR_M", "OR_S", "delta", "point_reversal", "both_opposite_95"]})
            except ValueError as exc:
                row["status"] = str(exc)
            sensitivity.append(row)
        verifications.append(dict(label, independent_covariance_error=error,
                                  allocation_identity_error=float(abs(values[2]-sum(values[3:]))),
                                  C_U_structurally_zero=True, C_V_equals_delta=True,
                                  source_relabeling="passed", outcome_swap="passed",
                                  nested_inference_status="finite_binary_margins",
                                  year_adjustment=diagnostics))
    estimates = pd.DataFrame(estimates)
    estimates.to_csv(OUT / "candidate_checks.csv", index=False)
    pd.DataFrame(denominators).to_csv(OUT / "boot_denominators.csv", index=False)
    pd.DataFrame(composition).to_csv(OUT / "composition.csv", index=False)
    sensitivity = pd.DataFrame(sensitivity)
    sensitivity.to_csv(OUT / "leave_serovar_out.csv", index=False)
    (OUT / "checks.json").write_text(json.dumps(verifications, indent=2)+"\n", encoding="utf-8")
    display = estimates[(estimates.metric.eq("delta")) | (
        estimates.candidate.eq(1) & estimates.metric.isin(["logOR_M", "logOR_S"]))]
    print(display[["candidate", "metric", "estimate", "low", "high", "uncertainty", "model"]].to_string(index=False))
    print(pd.DataFrame(denominators).to_string(index=False))
    print("Leave-one-serovar-out:")
    print(sensitivity.groupby("candidate").agg(attempts=("status", "size"),
          successes=("status", lambda x: x.eq("ok").sum()),
          reversals=("point_reversal", "sum"), delta_min=("delta", "min"),
          delta_max=("delta", "max")).to_string())
    print("Independent count, covariance, nested allocation and relabeling checks passed.")


if __name__ == "__main__":
    main()

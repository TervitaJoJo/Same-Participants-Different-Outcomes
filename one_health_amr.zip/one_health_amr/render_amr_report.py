"""Create a transparent feasibility report and provisional 600-dpi figure."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image


BASE = Path(__file__).resolve().parent
OUT = BASE / "results"
FIG = BASE / "figures"


def main():
    FIG.mkdir(exist_ok=True)
    estimates = pd.read_csv(OUT / "paired_estimates.csv")
    descriptive = pd.read_csv(OUT / "descriptive_point_estimates.csv")
    states = pd.read_csv(OUT / "state_counts.csv")
    denominators = pd.read_csv(OUT / "bootstrap_denominators.csv")
    manifest = json.loads((OUT / "analysis_manifest.json").read_text())
    retrieval = json.loads((BASE / "retrieval_manifest.json").read_text())
    attempts = pd.read_csv(OUT / "model_attempts.csv").fillna("")
    primary = estimates[estimates.analysis.eq("primary_turkey") & estimates.uncertainty.eq("source_stratified_isolate")].set_index("metric")
    counts = states.drop_duplicates(["source", "state"]).pivot(index="source", columns="state", values="n").reindex(index=["chicken breast", "ground turkey", "ground beef", "pork chop"], columns=["00","V","U","11"])

    figure_caption = (
        "Panel A shows joint-state counts for the four prespecified food sources, "
        "with each chicken-breast reference isolate represented once. M denotes "
        "submitted tetracycline AST resistance (R versus S); S denotes detection "
        "of a catalog-defined tetracycline-class core resistance determinant. "
        "Columns are joint states (M,S): 00, V=(0,1), U=(1,0), and 11. "
        "Panel B shows unadjusted log-OR(S) minus log-OR(M) for each source versus "
        "chicken breast. Filled points have paired source-stratified isolate "
        "bootstrap percentile 95% intervals conditional on full-state support; "
        "the open beef point is a finite descriptive estimate without an interval "
        "under the prespecified full-state inference screen. Panel C shows the "
        "fraction of attempted bootstrap replicates passing that screen, with "
        "successful/attempted counts printed as data labels. No bootstrap was "
        "attempted for the beef comparison after its original support screen failed. "
        "These failures concern the chosen inference procedure; they do not imply "
        "that all underlying contrasts are mathematically undefined. The figure "
        "is a provisional analysis display, pending journal-specific production checks"
    )
    with plt.rc_context({"font.family":"Arial", "font.size":8, "axes.labelsize":8,
                         "pdf.fonttype":42, "ps.fonttype":42, "figure.facecolor":"white",
                         "axes.facecolor":"white", "savefig.facecolor":"white"}):
        fig, axes = plt.subplots(1,3, figsize=(10.3,3.6), gridspec_kw={"width_ratios":[1.15,1,1.05]})
        fig.subplots_adjust(left=.075, right=.99, bottom=.21, top=.86, wspace=.62)
        table_ax, contrast_ax, denominator_ax = axes
        table_ax.axis("off")
        table = table_ax.table(cellText=[[f"{int(v):,}" for v in row] for row in counts.to_numpy()],
                              rowLabels=["Chicken breast", "Ground turkey", "Ground beef", "Pork chop"],
                              colLabels=["00", "V", "U", "11"], loc="center", cellLoc="center")
        table.auto_set_font_size(False)
        table.set_fontsize(8)
        table.scale(.86,1.7)
        for (r,c), cell in table.get_celld().items():
            cell.set_facecolor("white")
            cell.set_edgecolor("#d4d4d4")
            cell.set_linewidth(.4)
            if r == 0:
                cell.get_text().set_weight("bold")
            if c == -1:
                cell.set_edgecolor("white")

        names=[("primary_turkey","Ground turkey"), ("secondary_pork","Pork chop"), ("secondary_beef","Ground beef")]
        for y, (analysis, label) in enumerate(names):
            point = descriptive[descriptive.analysis.eq(analysis) & descriptive.metric.eq("delta_m")].iloc[0].estimate
            interval = estimates[estimates.analysis.eq(analysis) & estimates.metric.eq("delta_m") & estimates.uncertainty.eq("source_stratified_isolate")]
            if len(interval):
                row = interval.iloc[0]
                contrast_ax.plot([row.low,row.high],[y,y],color="#0072B2",lw=1.2)
                contrast_ax.plot(point,y,"o",ms=4,color="#0072B2")
            else:
                contrast_ax.plot(point,y,"o",ms=4,mfc="white",mec="#333333")
        contrast_ax.axvline(0,color="#777777",ls="--",lw=.8,zorder=0)
        contrast_ax.set_yticks(range(3), [item[1] for item in names])
        contrast_ax.set_ylim(2.7,-.7)
        contrast_ax.set_xlabel(r"Paired log-OR difference, $\Delta$")
        contrast_ax.set_xlim(-.09,.09)

        boot_rows = [
            denominators[denominators.analysis.eq("primary_turkey") & denominators.uncertainty.eq("source_stratified_isolate")].iloc[0],
            denominators[denominators.analysis.eq("primary_turkey") & denominators.uncertainty.eq("serovar_block")].iloc[0],
            denominators[denominators.analysis.eq("secondary_pork")].iloc[0],
        ]
        for y,row in enumerate(boot_rows):
            denominator_ax.barh(y,100*row.success_fraction, height=.43, color="#0072B2" if y < 2 else "#D55E00")
            denominator_ax.text(2,y,f"{row.successful:,}/{row.attempts:,}",va="center",ha="left",color="white",fontsize=8)
        denominator_ax.set_yticks(range(3), ["Turkey: isolate", "Turkey: serovar", "Pork: isolate"])
        denominator_ax.set_ylim(2.7,-.7)
        denominator_ax.set_xlim(0,103)
        denominator_ax.set_xticks([0,50,100])
        denominator_ax.set_xlabel("Supported bootstrap replicates (%)")
        for ax in [contrast_ax,denominator_ax]:
            ax.spines[["top","right"]].set_visible(False)
            ax.tick_params(length=3, width=.6)
            ax.spines[["left","bottom"]].set_linewidth(.6)
        for ax,letter in zip(axes,"ABC"):
            ax.text(-.12,1.08,letter,transform=ax.transAxes,fontweight="bold",fontsize=10,va="bottom")
        fig.savefig(FIG / "AMR_paired_state_audit.png", dpi=600)
        fig.savefig(FIG / "AMR_paired_state_audit.pdf")
        plt.close(fig)
    with Image.open(FIG / "AMR_paired_state_audit.png") as image:
        image_manifest={"width_px":image.width,"height_px":image.height,"dpi":list(image.info.get("dpi",())),"formats":["PNG","PDF"],"caption":"figure_caption.md"}
        assert min(image_manifest["dpi"]) >= 599
    (FIG / "figure_manifest.json").write_text(json.dumps(image_manifest,indent=2)+"\n",encoding="utf-8")
    (FIG / "figure_caption.md").write_text(figure_caption+"\n",encoding="utf-8")

    primary_n=int(primary.iloc[0].n)
    lines=[
        "# One Health 公共耐药数据扩展：分析结果与可用性判断",
        "",
        "结论：已完成一个真实的食品链抗菌药物耐药性配对应用，数据与代码可以公开复现。主比较没有出现方向逆转，适合展示高一致性下的配对关联核查；次要比较揭示了稀疏不一致状态对所选推断程序的限制。它应作为 One Health 外部应用，不应被包装成新的方向逆转证据。",
        "",
        "## 数据与共同分析样本",
        "",
        f"完整读取 NCBI 沙门菌版本 {retrieval['release']} 的 {retrieval['counts']['all_release_rows']:,} 条记录，服务器文件 {retrieval['retrieved_source_bytes']:,} 字节全部读取并核对。预设 NARMS 标记和肉品来源筛选后有 {retrieval['counts']['retained_source_rows']:,} 条记录；年份、有效药敏、基因判定、去重和质量筛选后有 {manifest['primary_isolates_all_sources']:,} 个独立 BioSample。",
        "",
        f"预设年份范围为 2002–2023；最终符合条件的配对样本覆盖 {manifest['primary_year_min']}–{manifest['primary_year_max']} 年。其余年份和药敏缺失情况保留在逐年可用性表中。主比较为火鸡肉末对鸡胸肉，n={primary_n:,}。所有样本均为食品来源分离株；本分析没有直接采集人、活体动物、土壤或水样。",
        "",
        "M 为提交记录中的四环素药敏 R（对照 S，I 类结果在主分析排除）；S 为同一分离株中检出 NCBI 固定版本目录定义的四环素类核心耐药决定因子。基因检出是独立的基因组指标，并未被当作临床表型金标准。观察到的匹配基因为 tet(A)、tet(B)、tet(C)、tet(G) 和 tet(M)。",
        "",
        "| 来源 | 00 | V：M−/S+ | U：M+/S− | 11 | 合计 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    cn_names={"chicken breast":"鸡胸肉","ground turkey":"火鸡肉末","ground beef":"牛肉末","pork chop":"猪排"}
    for source,row in counts.iterrows():
        lines.append(f"| {cn_names[source]} | {int(row['00']):,} | {int(row.V):,} | {int(row.U):,} | {int(row['11']):,} | {int(row.sum()):,} |")
    lines += ["", "## 主比较结果", "", "主比较采用共同样本上的未调整来源关联。此时 Δm 与 Δc 数值相同；年份调整结果单独报告，避免把未调整差值称为已调整效应。", "", "| 指标 | 估计值 | 配对 95% 区间 |", "|---|---:|---|" ]
    for metric,label in [("logOR_M","表型 OR"),("logOR_S","基因组指标 OR"),("delta_m","Δm = Δc"),("C_U","C_U"),("C_V","C_V"),("kappa","Cohen's kappa"),("disagreement","分类不一致比例")]:
        row=primary.loc[metric]
        values=np.array([row.estimate,row.low,row.high])
        if metric.startswith("logOR"):
            values=np.exp(values)
        if metric == "disagreement":
            lines.append(f"| {label} | {values[0]*100:.2f}% | {values[1]*100:.2f}% 至 {values[2]*100:.2f}% |")
        else:
            lines.append(f"| {label} | {values[0]:.4f} | {values[1]:.4f} 至 {values[2]:.4f} |")
    year=estimates[estimates.analysis.eq("adjusted_year") & estimates.metric.eq("delta_m") & estimates.uncertainty.eq("isolate_influence")].iloc[0]
    year_cluster=estimates[estimates.analysis.eq("adjusted_year") & estimates.metric.eq("delta_m") & estimates.uncertainty.eq("serovar_cluster_influence")].iloc[0]
    lines += [
        "",
        f"年份调整后的标准化 Δm 为 {year.estimate:.4f}（独立分离株影响函数区间 {year.low:.4f} 至 {year.high:.4f}；血清型聚类区间 {year_cluster.low:.4f} 至 {year_cluster.high:.4f}）。两个定义下的主比较方向一致，配对差值区间均跨 0。将 I 纳入不敏感定义后，差值仍接近 0。附加基因组质量阈值没有进一步排除有效配对样本。",
        "",
        "当前比较没有检出明确的定义差异；这不是预设等效性界值下的正式等效性检验。两种定义的临床含义与一般可互换性还需要独立证据。",
        "",
        "## 推断支持和失败分母",
        "",
        "| 分析 | 重抽样单位 | 成功 / 尝试 | 失败 | 成功比例 |",
        "|---|---|---:|---:|---:|",
    ]
    for row in denominators.itertuples():
        lines.append(f"| {row.analysis} | {row.uncertainty} | {row.successful:,}/{row.attempts:,} | {row.failed:,} | {row.success_fraction*100:.2f}% |")
    beef=descriptive[descriptive.analysis.eq("secondary_beef") & descriptive.metric.eq("delta_m")].iloc[0]
    lines += [
        "",
        "这里的成功要求是预先选定的完整 source×state 推断程序在八个单元格均有观察支持。空单元格不意味着所有点估计在数学上都未定义。",
        "",
        f"牛肉组的 U、V 均为零，其描述性配对差值仍可计算（Δ={beef.estimate:.4f}），并已保留；按照预设规则，不为该比较提供完整状态推断区间。猪肉组 U、V 仅为 2、1；大量重抽样出现空单元格。其条件区间必须连同失败分母解释，不能把成功的那部分重复当作稳定推断的全部证据。",
        "",
        "年份＋血清型调整模型被优化器标记为收敛，但返回非有限系数，未通过后续检查，因此未报告其效应区间。详细尝试、警告和诊断保留在 model_attempts.csv；未通过诊断的模型没有被替换成一个看似成功的结果。",
        "",
        "经验数据重抽样没有已知真值，因而本报告不计算覆盖率或‘成功＋覆盖率’。这些分母是经验分析的可计算性记录，与原稿模拟中的覆盖评估属于不同证据。",
        "",
        "## 对 One Health 稿件的意义",
        "",
        "这个应用把审计推广到食品链耐药监测中的同一分离株、不同检测定义。它提供两层证据：主比较显示高一致性下来源关联差值较小；稀疏来源组显示总体一致性不能替代分组后不一致状态支持的检查。食品源沙门菌与人类食源性疾病的联系构成 One Health 背景，但本数据不能识别动物到人的传播方向或跨部门传播率。",
        "",
        "建议保留原稿人群分析的主要发现，将本结果纳入一个有实质数据支持的食品链 AMR 外部应用。新的叙事重点应是‘同一报告原则跨人群与食品链监测适用，并显式呈现推断边界’，不能声称 AMR 复制了原稿的方向逆转。",
        "",
        "## 解释边界与复核",
        "",
        "这是公开测序并提交有效药敏结果的监测子集，没有抽样权重；来源比较同时包含商品类型、加工方式、血清型和年份构成差异。AST 使用提交者的判定，未取得完整 MIC 与统一断点信息以重新判定耐药。血清型聚类仅是依赖敏感性检查，并不重建零售抽样设计。所有来源、失败分析和排除记录均保留。",
        "",
        "已通过独立核验：二项 logistic OR 与联合模型一致、双顺序分配与既有公式一致、交换定义和来源后的符号关系正确、配对协方差保留、所有重抽样分母对账、每次有效重抽样满足 C_U+C_V=Δ，以及完整下载与冻结方案哈希核验。",
        "",
        "## 复现与资料",
        "",
        "运行 `python reproduce_amr.py` 可使用已包含的公开源记录子集离线重建分析、验证、图和本报告。重新从官方完整版本抓取源记录时运行 `python download_full_narms.py`；这会重新读取约 866 MB，日常复现不需要这一步。",
        "",
        "- `ANALYSIS_PLAN.md`：完整下载和来源关联计算前固定的本地方案，未进行外部预注册",
        "- `retrieval_manifest.json`：版本、端点、完整字节对账和 SHA-256",
        "- `data/analytic_primary.csv`：公开细菌分离株分析样本，不含受限人群记录",
        "- `results/paired_estimates.csv`：全部可接受估计和条件区间",
        "- `results/descriptive_point_estimates.csv`：包括牛肉边界样本在内的有限点估计",
        "- `results/bootstrap_*.csv`：每次尝试及失败原因",
        "- `results/verification.json`：独立计算检查",
        "",
        "官方来源：",
        "",
        f"- {retrieval['source_url']}",
        f"- {retrieval['catalog_url']}",
        "- https://ftp.ncbi.nlm.nih.gov/pathogen/ReadMe.txt",
        "- https://www.ebi.ac.uk/ena/browser/view/SAMN02640788",
        "- https://www.ebi.ac.uk/ena/browser/view/PRJNA292661",
        "",
        "相关原始研究：Nguyen M, et al. Using Machine Learning To Predict Antimicrobial MICs and Associated Genomic Features for Nontyphoidal Salmonella. J Clin Microbiol. 2019;57:e01260-18. https://doi.org/10.1128/JCM.01260-18 。该文是已核实样本链接的文献背景；本次分析使用的实际输入是上述固定版本公开数据库，而非声称复现该文的 MIC 模型。",
    ]
    (BASE / "AMR_analysis_report_zh.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(image_manifest,indent=2))
    print("Wrote AMR_analysis_report_zh.md")


if __name__ == "__main__":
    main()

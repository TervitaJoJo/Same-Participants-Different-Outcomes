"""Render the food-chain application from the audited aggregate CSV results.

Adapts render_amr_report.py's state table, paired intervals and denominator
display; adds both outcome-specific ORs so stable direction is directly visible.
Native and manuscript widths are 174 mm: the 8-point text is not reduced.
"""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image


BASE = Path(__file__).resolve().parent
OUT = BASE / "results"
FIG = BASE / "figures"
STEM = "Figure5_food_chain_AMR"
BLUE = "#0072B2"
CORAL = "#D55E00"

CAPTION = (
    "Fig. 5 Paired indicators and inference support in food-chain antimicrobial "
    "resistance surveillance. Panel A shows observed isolate counts by meat "
    "source and joint state, ordered (M,S): 00, V=(0,1), U=(1,0), and 11. "
    "M denotes submitted tetracycline susceptibility-test resistance "
    "(resistant versus susceptible); S denotes detection of a catalog-defined "
    "tetracycline-class core resistance determinant. Panel B connects the "
    "unadjusted source-association odds ratios under M (blue circles) and S "
    "(coral squares), each relative to chicken breast. The axis uses a "
    "logarithmic scale and the reference line marks OR=1. Panel C shows "
    "paired log-OR differences, log OR(S) minus log OR(M), with percentile "
    "95% intervals from source-stratified isolate resampling and a serovar-block "
    "sensitivity analysis. The open beef point is a finite descriptive estimate; "
    "its interval was withheld under the prespecified full-state support screen. "
    "Panel D shows successful/attempted bootstrap counts for that screen. "
    "No beef bootstrap was attempted after the original sample failed the "
    "screen. The screen governs the selected inference procedure; it does not "
    "define the mathematical existence of the descriptive contrast"
)


def main():
    FIG.mkdir(exist_ok=True)
    estimates = pd.read_csv(OUT / "paired_estimates.csv")
    descriptive = pd.read_csv(OUT / "descriptive_point_estimates.csv")
    states = pd.read_csv(OUT / "state_counts.csv")
    denominators = pd.read_csv(OUT / "bootstrap_denominators.csv")
    counts = (
        states.drop_duplicates(["source", "state"])
        .pivot(index="source", columns="state", values="n")
        .reindex(
            index=["chicken breast", "ground turkey", "ground beef", "pork chop"],
            columns=["00", "V", "U", "11"],
        )
    )
    names = [
        ("primary_turkey", "Ground turkey"),
        ("secondary_beef", "Ground beef"),
        ("secondary_pork", "Pork chop"),
    ]
    rc = {
        "font.family": "Arial", "font.size": 8, "axes.labelsize": 8,
        "pdf.fonttype": 42, "ps.fonttype": 42, "figure.facecolor": "white",
        "axes.facecolor": "white", "savefig.facecolor": "white",
    }
    with plt.rc_context(rc):
        fig, axes = plt.subplots(2, 2, figsize=(174 / 25.4, 142 / 25.4))
        fig.subplots_adjust(left=.17, right=.98, bottom=.11, top=.94,
                            wspace=.87, hspace=.62)
        table_ax, association_ax, contrast_ax, denominator_ax = axes.ravel()
        table_ax.axis("off")
        table = table_ax.table(
            cellText=[[f"{int(v):,}" for v in row] for row in counts.to_numpy()],
            rowLabels=["Chicken breast", "Ground turkey", "Ground beef", "Pork chop"],
            colLabels=["00", "V", "U", "11"],
            bbox=[.04, .05, .96, .85], cellLoc="center",
        )
        table.auto_set_font_size(False)
        table.set_fontsize(8)
        for (r, c), cell in table.get_celld().items():
            cell.set_facecolor("white")
            cell.set_edgecolor("#d4d4d4" if c >= 0 else "white")
            cell.set_linewidth(.4)
            if r == 0:
                cell.get_text().set_weight("bold")
            if c == -1:
                cell.PAD = .03

        for y, (analysis, label) in enumerate(names):
            row = descriptive[descriptive.analysis.eq(analysis)].set_index("metric")
            m, s = np.exp(row.loc[["logOR_M", "logOR_S"], "estimate"])
            assert (m - 1) * (s - 1) > 0, (analysis, m, s)
            association_ax.plot([m, s], [y - .10, y + .10], color="#777777", lw=.9)
            association_ax.plot(m, y - .10, "o", ms=4, color=BLUE)
            association_ax.plot(s, y + .10, "s", ms=4, color=CORAL)
        association_ax.set_xscale("log")
        association_ax.set_xlim(.22, 1.22)
        association_ax.set_xticks([.25, .5, 1], ["0.25", "0.5", "1"])
        association_ax.minorticks_off()
        association_ax.set_yticks(range(3), [item[1] for item in names])
        association_ax.set_ylim(2.6, -.6)
        association_ax.axvline(1, color="#777777", ls="--", lw=.7, zorder=0)
        association_ax.set_xlabel("Source association (OR)")

        interval_rows = [
            ("primary_turkey", "source_stratified_isolate", "Turkey: isolate"),
            ("primary_turkey", "serovar_block", "Turkey: serovar"),
            ("secondary_beef", "source_stratified_isolate", "Beef"),
            ("secondary_pork", "source_stratified_isolate", "Pork: isolate"),
        ]
        for y, (analysis, uncertainty, label) in enumerate(interval_rows):
            point = descriptive[
                descriptive.analysis.eq(analysis) & descriptive.metric.eq("delta_m")
            ].iloc[0].estimate
            interval = estimates[
                estimates.analysis.eq(analysis) & estimates.metric.eq("delta_m")
                & estimates.uncertainty.eq(uncertainty)
            ]
            if len(interval):
                row = interval.iloc[0]
                contrast_ax.plot([row.low, row.high], [y, y], color=BLUE, lw=1.1)
                contrast_ax.plot(point, y, "o", ms=4, color=BLUE)
            else:
                contrast_ax.plot(point, y, "o", ms=4, mfc="white", mec="#333333")
        contrast_ax.axvline(0, color="#777777", ls="--", lw=.7, zorder=0)
        contrast_ax.set_yticks(range(4), [r[2] for r in interval_rows])
        contrast_ax.set_ylim(3.6, -.6)
        contrast_ax.set_xlim(-.09, .075)
        contrast_ax.set_xticks([-.08, -.04, 0, .04])
        contrast_ax.set_xlabel(r"Paired log-OR difference, $\Delta_m$")

        boot_rows = [
            denominators[
                denominators.analysis.eq(a) & denominators.uncertainty.eq(u)
            ].iloc[0]
            for a, u in [
                ("primary_turkey", "source_stratified_isolate"),
                ("primary_turkey", "serovar_block"),
                ("secondary_pork", "source_stratified_isolate"),
            ]
        ]
        for y, row in enumerate(boot_rows):
            denominator_ax.barh(y, 100 * row.success_fraction, height=.45,
                                color=BLUE if y < 2 else CORAL)
            denominator_ax.text(3, y, f"{row.successful:,}/{row.attempts:,}",
                                va="center", color="white", fontsize=8)
        denominator_ax.set_yticks(range(3), ["Turkey: isolate", "Turkey: serovar", "Pork: isolate"])
        denominator_ax.set_ylim(2.6, -.6)
        denominator_ax.set_xlim(0, 103)
        denominator_ax.set_xticks([0, 50, 100])
        denominator_ax.set_xlabel("Supported bootstrap replicates (%)")

        for ax in [association_ax, contrast_ax, denominator_ax]:
            ax.spines[["top", "right"]].set_visible(False)
            ax.spines[["left", "bottom"]].set_linewidth(.6)
            ax.tick_params(length=3, width=.6, pad=3)
        for ax, letter in zip(axes.ravel(), "ABCD"):
            position = ax.get_position()
            fig.text(position.x0 - .14, position.y1 + .025, letter,
                     fontweight="bold", fontsize=10)
        fig.savefig(FIG / f"{STEM}.pdf")
        fig.savefig(FIG / f"{STEM}.png", dpi=1000)
        plt.close(fig)
    with Image.open(FIG / f"{STEM}.png") as image:
        image.save(FIG / f"{STEM}.tif", compression="tiff_lzw", dpi=(1000, 1000))
        manifest = {
            "width_px": image.width, "height_px": image.height,
            "dpi": list(image.info["dpi"]), "native_width_mm": 174,
            "native_height_mm": 142, "base_font_pt": 8,
            "data": ["state_counts.csv", "descriptive_point_estimates.csv",
                     "paired_estimates.csv", "bootstrap_denominators.csv"],
            "source_script": "Adapted from render_amr_report.py",
            "no_direction_reversal": True,
        }
    (FIG / f"{STEM}_caption.txt").write_text(CAPTION + "\n", encoding="utf-8")
    (FIG / f"{STEM}_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()

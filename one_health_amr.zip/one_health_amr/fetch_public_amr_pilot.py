"""Verify paired public AMR records using a bounded, version-pinned download."""

import csv
import hashlib
import io
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET


BASE = Path(__file__).resolve().parent
VERSION = "PDG000000002.4261"
URL = (
    "https://ftp.ncbi.nlm.nih.gov/pathogen/Results/Salmonella/"
    f"{VERSION}/AMR/{VERSION}.amr.metadata.tsv"
)
PREFIX_BYTES = 4_000_000
MISSING = {"", "null", "missing", "not provided", "not collected", "n/a", "na"}
FIELDS = [
    "#label", "biosample_acc", "bioproject_acc", "sample_name", "strain",
    "scientific_name", "serovar", "host", "isolation_source", "source_type",
    "epi_type", "collection_date", "geo_loc_name", "food_origin", "Run",
    "asm_acc", "target_acc", "number_drugs_tested", "AST_phenotypes",
    "AMR_genotypes", "AMR_genotypes_core", "amrfinder_applied",
    "amrfinder_version", "refgene_db_version", "amrfinder_analysis_type",
]


def write_csv(path, records, fieldnames):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def phenotypes(row):
    value = row["AST_phenotypes"]
    if value.strip().lower() in MISSING:
        return {}
    return dict(item.rsplit("=", 1) for item in value.split(",") if "=" in item)


def main():
    request = Request(
        URL,
        headers={
            "Range": f"bytes=0-{PREFIX_BYTES - 1}",
            "User-Agent": "paired-state-public-data-feasibility/1.0",
        },
    )
    with urlopen(request, timeout=45) as response:
        if response.status != 206:
            raise RuntimeError("Server did not honor the bounded Range request")
        raw = response.read(PREFIX_BYTES)
        content_range = response.headers.get("Content-Range")
        last_modified = response.headers.get("Last-Modified")
    if len(raw) != PREFIX_BYTES:
        raise RuntimeError("Incomplete prefix retrieval")

    # The last line may be a partial TSV record at the byte boundary.
    complete_text = raw[:raw.rfind(b"\n") + 1].decode("utf-8")
    rows = list(csv.DictReader(io.StringIO(complete_text), delimiter="\t"))
    candidates = [
        row for row in rows
        if row["amrfinder_applied"] == "1"
        and any(value in {"R", "S", "I"} for value in phenotypes(row).values())
    ]
    if not candidates:
        raise RuntimeError("No candidate paired records in the prefix")
    write_csv(
        BASE / "public_salmonella_pilot.csv",
        [{("label" if field == "#label" else field): row[field]
          for field in FIELDS} for row in candidates],
        ["label" if field == "#label" else field for field in FIELDS],
    )
    counts = Counter(row["isolation_source"] for row in candidates)
    write_csv(
        BASE / "pilot_source_counts.csv",
        [{"isolation_source": source, "candidate_records": n}
         for source, n in counts.most_common()],
        ["isolation_source", "candidate_records"],
    )

    sample_url = "https://www.ebi.ac.uk/ena/browser/api/xml/SAMN02640788"
    with urlopen(sample_url, timeout=30) as response:
        sample_xml = response.read(200_000)
    root = ET.fromstring(sample_xml)
    attributes = {
        item.findtext("TAG"): item.findtext("VALUE")
        for item in root.findall(".//SAMPLE_ATTRIBUTE")
    }
    sample_check = {
        "url": sample_url,
        "accession": "SAMN02640788",
        "project_name": attributes.get("project_name"),
        "isolation_source": attributes.get("isolation source"),
        "narms_isolate_number": attributes.get("NARMS isolate number"),
        "sequence_links": [
            link.findtext("ID") for link in root.findall(".//XREF_LINK")
            if link.findtext("DB") == "ENA-FASTQ-FILES"
        ],
    }
    manifest = {
        "accessed_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Targeted availability check; nonrandom file prefix",
        "source_url": URL,
        "release": VERSION,
        "request_range": f"bytes=0-{PREFIX_BYTES - 1}",
        "response_content_range": content_range,
        "response_last_modified": last_modified,
        "prefix_bytes": len(raw),
        "prefix_sha256": hashlib.sha256(raw).hexdigest(),
        "complete_rows_in_prefix": len(rows),
        "rows_excluded_without_completed_genotype_and_valid_AST": len(rows) - len(candidates),
        "candidate_records": len(candidates),
        "unique_candidate_biosamples": len({row["biosample_acc"] for row in candidates}),
        "source_counts": dict(counts),
        "bioproject_counts": dict(Counter(row["bioproject_acc"] for row in candidates)),
        "valid_AST_calls": dict(Counter(
            call for row in candidates for call in phenotypes(row).values()
            if call in {"R", "S", "I"}
        )),
        "example_sample_cross_check": sample_check,
        "limitations": [
            "This is a prefix check, not a complete or representative study sample.",
            "No drug-specific genotype prediction rule or association was evaluated.",
            "A NULL genotype list is not a failed run when amrfinder_applied is 1.",
            "The environmental/other category includes food and does not establish an environmental sample.",
            "Drug breakpoints, intermediate results, genomic quality and sampling design need a protocol.",
            "Sequences and raw laboratory measurements were not downloaded.",
        ],
    }
    (BASE / "availability_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=True))


if __name__ == "__main__":
    main()

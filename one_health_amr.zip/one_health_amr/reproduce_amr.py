"""Reproduce all results offline from the included public source subset."""

import argparse
import subprocess
import sys
from pathlib import Path


BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--include-exploratory", action="store_true",
                    help="Also reproduce both exploratory families (54 marker and 114 threshold comparisons).")
parser.add_argument("--include-reviewer-checks", action="store_true",
                    help="Include both exploratory families and all offline reviewer checks.")
args = parser.parse_args()
scripts = ["run_amr_audit.py", "verify_amr_audit.py", "render_amr_report.py",
           "plot_submission_figure.py"]
if args.include_exploratory or args.include_reviewer_checks:
    scripts.extend(["exploratory/scan_reversals.py", "exploratory/check_candidates.py",
                    "exploratory/scan_thresholds.py", "exploratory/check_threshold_candidates.py",
                    "exploratory/verify_thresholds.py"])
if args.include_reviewer_checks:
    scripts.append("checks/run_checks.py")
for script in scripts:
    subprocess.run([sys.executable, "-B", str(BASE / script)], check=True, cwd=BASE)

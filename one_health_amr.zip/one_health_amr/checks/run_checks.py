"""Reproduce all reviewer checks offline from the bundled public/synthetic inputs."""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for name in ["simulation.py", "composition.py", "multiplicity.py", "provenance.py", "verify.py"]:
    subprocess.run([sys.executable, "-B", str(ROOT / name)], cwd=ROOT, check=True)

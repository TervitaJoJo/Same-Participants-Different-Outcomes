"""Analytic paired estimands and empirical standardization for reviewer checks."""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from scipy.stats import norm, t

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import paired_core as core

NAMES = ["logOR_M", "logOR_S", "delta", "C_U", "C_V"]


def metrics(q):
    """Values and exact Jacobian, including valid boundary joint probabilities."""
    q = np.asarray(q, float).reshape(2, 4)
    if not np.isfinite(q).all() or (q < -1e-12).any():
        raise ValueError("invalid_joint_probability")
    masks = np.array([[0, 0, 1, 1], [0, 1, 0, 1],
                      [0, 0, 0, 1], [0, 1, 1, 1]])
    ls, grads = [], []
    for mask in masks:
        risk = q @ mask
        if ((risk <= 0) | (risk >= 1)).any():
            ls.append(np.nan)
            grads.append(np.full(8, np.nan))
        else:
            ls.append(logit(risk[1])-logit(risk[0]))
            grads.append(np.r_[-mask/(risk[0]*(1-risk[0])),
                               mask/(risk[1]*(1-risk[1]))])
    transform = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [-1, 1, 0, 0],
                          [-.5, .5, .5, -.5], [-.5, .5, -.5, .5]])
    # Evaluate only needed terms: zero times NaN must not invalidate Delta.
    values, jac = [], []
    for weights in transform:
        use = weights != 0
        values.append(weights[use] @ np.asarray(ls)[use])
        jac.append(weights[use] @ np.asarray(grads)[use])
    return np.array(values), np.array(jac)


def standardize(g, strata):
    """Pooled empirical target; IF includes estimation of target weights."""
    n = len(g)
    if n == 0:
        raise ValueError("empty_target")
    keys = g[strata].astype(str).agg("|".join, axis=1) if strata else pd.Series("all", index=g.index)
    e = g.E.to_numpy(int)
    state = (2*g.M+g.S).to_numpy(int)
    q = np.zeros((2, 4))
    ip = np.zeros((n, 8))
    pieces = []
    for key in sorted(keys.unique()):
        ix = np.flatnonzero(keys.to_numpy() == key)
        w = len(ix)/n
        for level in [0, 1]:
            jx = ix[e[ix] == level]
            if len(jx) == 0:
                raise ValueError("empty_exposure_covariate_cell")
            p = np.bincount(state[jx], minlength=4)/len(jx)
            q[level] += w*p
            ip[jx, level*4:(level+1)*4] += w/len(jx)*(np.eye(4)[state[jx]]-p)
            pieces.append((ix, level, p))
    for ix, level, p in pieces:
        ip[ix, level*4:(level+1)*4] += (p-q[level])/n
    values, jac = metrics(q)
    return values, ip @ jac.T, q, ip


def intervals(g, values, influence, model, target, extra=None):
    rows = []
    for uncertainty in ["isolate", "serovar_cluster"]:
        cluster = np.arange(len(g)) if uncertainty == "isolate" else pd.factorize(g.serovar_clean)[0]
        count = len(np.unique(cluster))
        if count < 2:
            continue
        cov, df = core.cov_cluster(influence, g.assign(strata=1, cluster=cluster))
        critical = norm.ppf(.975) if uncertainty == "isolate" else t.ppf(.975, df)
        for j, metric in enumerate(NAMES):
            se = np.sqrt(max(0, cov[j, j]))
            p = 2*(norm.sf(abs(values[j])/se) if uncertainty == "isolate"
                   else t.sf(abs(values[j])/se, df)) if se > 0 else np.nan
            rows.append(dict(model=model, target=target, uncertainty=uncertainty,
                             metric=metric, estimate=values[j], se=se,
                             low=values[j]-critical*se, high=values[j]+critical*se,
                             p=p, n=len(g), clusters=count, df=df, **(extra or {})))
    return rows

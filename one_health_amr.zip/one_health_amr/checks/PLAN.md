# Reviewer-driven checks, 15 October 2026

This exploratory amendment follows review of the existing results. No claim
of preregistration or independent confirmation is made. Existing results and
the submission manuscript remain unchanged. All new analyses are retained.

## 1. Simulation screening calibration

Regenerate the original very_sparse, n=500, replicates 0-399, from seed
202609202 and scenario index 2. Preserve the original generating mechanism
and standardization truth. Archive synthetic input rows and the exact
generating-code provenance so this extension runs offline in the public
bundle. These records are synthetic, with no human participants.

Compare: (a) the historical eight-state-cell pre-screen and unchanged joint
multinomial model; (b) the same joint model without that pre-screen, retaining
convergence, finite coefficient, Hessian and probability checks; (c) paired
binary GLMs with exposure-by-three-level-covariate saturation, standardized
to the same empirical target, retaining cross-outcome covariance; and (d)
direct saturated empirical joint probabilities by exposure/covariate,
allowing empty joint outcome cells but requiring positive exposure/covariate
sample support and finite probabilities for each requested logit.

Methods target the same population Delta_m but make different regression
assumptions; the saturated methods exploit the finite covariate support and
are diagnostic benchmarks, not a claimed universal preferred estimator.
The empirical joint method also reports C_U and C_V. Use analytic gradients
and empirical influence covariance; distinguish finite point values, positive
variance, boundary cells and model failures. Report the original attempt
denominator for every metric, bias, Monte Carlo error, conditional interval
coverage and success-plus-coverage. Do not infer universal nonestimability
from one procedure's failure. Count and retain all failures and warnings.

## 2. AST provenance and comparability

Target the amoxicillin-clavulanic acid candidate (ground beef vs ground
turkey), all 2,537 existing BioSamples. Inspect existing source metadata for
AST laboratory, protocol, MIC and breakpoint fields. Do not substitute a
sequencing centre for the AST laboratory. Query official FDA NARMS pages
and documentation for public isolate-level MIC downloads. Cross-check a
bounded, deterministic selection of up to 12 BioSample records spanning
source, year and submitted AST category through ENA/NCBI official endpoints.
Log URLs, dates, responses, checksums and gaps. No more than 60 HTTP calls
or 10,000 API records in this bounded retrieval. Do not send unpublished
manuscript text to a service.

If a linkable complete MIC dataset and applicable standard are obtained,
document the join and fixed breakpoint before reclassification. Otherwise
report the unavailable harmonization explicitly. Produce source/year/project
AST composition tables and pooled common-year and common-project sensitivity
estimates, without selecting periods or projects by the association result.
Every listed sensitivity is retained. These checks cannot prove protocol
comparability where metadata are missing.

## 3. Composition and common support

Use only the existing amoxicillin-clavulanic acid main candidate; do not
search new drugs or source contrasts. Tabulate serovar, year and their joint
support by source, retaining zero cells. Predefine these targets: all shared
serovars (>=1 isolate per source); shared serovar/year strata (>=1 per
source); and a precision sensitivity requiring >=5 isolates per source in
each serovar/year stratum. Report any empty restricted target as a failure.

For each target report the crude comparison within the restricted sample,
then standardize empirical three-category probabilities (S,I,R) to its
pooled observed stratum distribution. Derive both binary indicators from
the same probability vector. Retain paired covariance and account for
empirical target weights in the influence function. Use isolate and
serovar-clustered intervals where at least two clusters support them.
The support definition is held fixed for inference, and changing targets
must not be interpreted as a pure change in adjustment.

As a model sensitivity, on shared-serovar support fit a three-category
multinomial model with source, centered year and serovar. Retain separate
attempts for all shared serovars and for the five most frequent shared
serovars with at least five observations per source, pooling the remainder.
Determine frequency groups without outcome labels. Reject nonfinite or
nonconverged fits, poor Hessian condition (>1e12), invalid probabilities or
score checks. Fit failure is an output, not a reason to change the model.

U=0 is structural for nested R/R-or-I endpoints. Three-state support is
appropriate; the unconstrained four-state full-support screen is inapplicable.
This is descriptive composition sensitivity, not causal identification.

## 4. Consistent exploratory inference

Recompute the 168 previously reported exploratory paired-difference tests
using serovar-clustered empirical influence covariance and t critical values,
retaining nonestimable cases with p=1, then Holm correction over all 168.
Retain the earlier independent-isolate results for comparison. Candidate
adjusted models are sensitivity analyses, not newly confirmatory tests.
No outcome-dependent choice of variance method or correction is allowed.

## Data-quality amendment after support inspection

Inspection showed that the only serovar/year stratum meeting >=5 per source
was labelled Unknown, a missing-metadata category rather than an identified
serovar. Preserve all original targets (which retain that explicit category)
and add parallel known-serovar-only versions of each of the three empirical
targets. Run all three even if the target is empty. This amendment addresses
missing serovar identity; it does not select targets by effect size or p-value.

## Deliverables

Code, source/provenance tables, all attempted fits, numerical verification,
and a Chinese interpretation report under one_health_amr/checks/. Update
the existing code archive, keeping every directory below 100 files. No
manuscript change until the consequences of these checks are reviewed.

# Generating-code provenance

`historical_sim.txt` is an unchanged byte copy of the original
`analysis/allocation_simulation_20260920/run_audited.py` in the historical
code collection. Its SHA-256 is recorded in `../sim/manifest.json`.

`../simulation.py` parses this snapshot and executes only the explicitly
allowlisted generating constants, scenario setup, truth, generator and
support-check function definitions. It does not execute the original
whole-study entry point, file exports, manifest access or manuscript paths.
The copied `paired_core.py` has the same SHA-256 as the original
`mechanism_followup_20260917/code/common.py`; both are unchanged.

The snapshot permits regeneration of the identical 400 synthetic samples
using the historical random seed without access to the original workstation.
`../sim/synthetic.csv.gz` is a derived synthetic convenience export, not
participant-level cohort data. Reproduction regenerates it and checks all
400 samples against the generator.

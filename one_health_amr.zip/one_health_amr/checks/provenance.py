"""Bounded official metadata retrieval; cached snapshots support offline review."""

import argparse
import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

import pandas as pd

from composition import candidate
from estimators import intervals, standardize

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "provenance"
CACHE = OUT / "cache"
FDA = "https://www.fda.gov/animal-veterinary/national-antimicrobial-resistance-monitoring-system/narms-now-integrated-data"


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.href = None
        self.label = []
        self.text = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self.href = dict(attrs).get("href")
            self.label = []

    def handle_data(self, data):
        self.text.append(data.strip())
        if self.href:
            self.label.append(data.strip())

    def handle_endtag(self, tag):
        if tag == "a" and self.href:
            self.links.append((self.href, " ".join(self.label)))
            self.href = None


def fetch(url, name, online):
    logpath = OUT / "requests.json"
    log = json.loads(logpath.read_text()) if logpath.exists() else []
    prior = next((r for r in log if r["url"] == url), None)
    if prior:
        path = CACHE / prior["cache_file"]
        return path.read_bytes() if path.exists() else None
    if not online:
        raise RuntimeError("Snapshot missing; use --fetch for bounded official retrieval")
    if len(log) >= 60:
        raise RuntimeError("60 request budget exhausted")
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in {"www.fda.gov", "www.ebi.ac.uk", "www.ncbi.nlm.nih.gov", "www.accessdata.fda.gov", "eutils.ncbi.nlm.nih.gov"}:
        raise ValueError("unapproved official host")
    row = dict(url=url, accessed_utc=datetime.now(timezone.utc).isoformat(), cache_file=name)
    data = None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "PairedStateAudit/1.0 (public research metadata)"})
        with urllib.request.urlopen(req, timeout=25) as response:
            data = response.read(20_000_001)
            if len(data) > 20_000_000:
                raise ValueError("response exceeds bounded snapshot size")
            row.update(status=response.status, final_url=response.url, content_type=response.headers.get("Content-Type", ""))
    except Exception as exc:
        row.update(status="failed", error=type(exc).__name__+": "+str(exc))
    if data is not None:
        (CACHE / name).write_bytes(data)
        row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    log.append(row)
    logpath.write_text(json.dumps(log, indent=2)+"\n", encoding="utf-8")
    print(f"HTTP {len(log)} {row['status']} {url}", flush=True)
    time.sleep(.25)
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch", action="store_true")
    parser.add_argument("--url", action="append", default=[])
    args = parser.parse_args()
    CACHE.mkdir(parents=True, exist_ok=True)
    g = candidate()
    raw = pd.read_csv(ROOT.parent / "data/narms_retail_source_records.csv", dtype=str, keep_default_na=False)
    match = g.merge(raw.drop(columns=["source", "year"], errors="ignore"),
                    on=["biosample_acc", "target_acc"], validate="one_to_one")
    assert len(match) == 2537
    inventory = []
    for col in raw.columns:
        values = match[col]
        known = ~values.isin(["", "NULL", "missing", "not provided", "not collected", "N/A", "NA"])
        inventory.append(dict(field=col, available=int(known.sum()), missing=int((~known).sum()),
                              distinct_known=values[known].nunique()))
    pd.DataFrame(inventory).to_csv(OUT / "field_inventory.csv", index=False)
    for dim in ["year", "bioproject_acc", "serovar_clean"]:
        match.groupby([dim, "source", "AST"]).size().rename("n").reset_index().to_csv(OUT / (dim+"_AST.csv"), index=False)
    estimates, attempts = [], []
    for dim in ["year", "bioproject_acc"]:
        counts = match.groupby([dim, "E"]).size().unstack("E", fill_value=0).reindex(columns=[0, 1], fill_value=0)
        common = counts.index[(counts > 0).all(axis=1)]
        part = match[match[dim].isin(common)].reset_index(drop=True)
        try:
            value, psi, _, _ = standardize(part, [])
            estimates.extend(intervals(part, value, psi, "crude_common_support", "common_"+dim))
            attempts.append(dict(dimension=dim, status="ok", common_levels=len(common),
                                 levels=";".join(map(str, common)), n=len(part),
                                 point_reversal=bool(value[0]*value[1] < 0)))
        except Exception as exc:
            attempts.append(dict(dimension=dim, status="failed", n=len(part), reason=str(exc)))
    pd.DataFrame(estimates).to_csv(OUT / "common_support_estimates.csv", index=False)
    pd.DataFrame(attempts).to_csv(OUT / "common_support_attempts.csv", index=False)
    picked = []
    for (source, category), part in match.groupby(["source", "AST"], sort=True):
        ordered = part.sort_values(["year", "biosample_acc"])
        picked.extend([ordered.iloc[0], ordered.iloc[-1]])
    selected = pd.DataFrame(picked).drop_duplicates("biosample_acc")
    selected[["biosample_acc", "source", "year", "AST", "bioproject_acc", "isolate_identifiers"]].to_csv(OUT / "selected_samples.csv", index=False)
    fda = fetch(FDA, "fda.html", args.fetch)
    all_links = []
    logs = json.loads((OUT / "requests.json").read_text())
    pages = {r["url"]: r["cache_file"] for r in logs
             if urllib.parse.urlparse(r["url"]).hostname in {"www.fda.gov", "www.accessdata.fda.gov"}}
    pages.update({u: "fda_"+hashlib.sha256(u.encode()).hexdigest()[:10]+".html" for u in args.url})
    for url, name in pages.items():
        data = fda if url == FDA else fetch(url, name, args.fetch)
        if data and b"<html" in data[:10000].lower():
            html = Links()
            html.feed(data.decode("utf-8", errors="replace"))
            (OUT / (name+".txt")).write_text("\n".join(t for t in html.text if t), encoding="utf-8")
            for href, label in html.links:
                absolute = urllib.parse.urljoin(url, href)
                if re.search(r"narms|suscept|breakpoint|\.csv|\.zip|\.xlsx|\.pdf|download|method", absolute+" "+label, re.I):
                    all_links.append(dict(page=url, url=absolute, label=label))
    if all_links:
        pd.DataFrame(all_links).drop_duplicates().to_csv(OUT / "official_links.csv", index=False)
    attributes = []
    for row in selected.itertuples():
        accession = row.biosample_acc
        assert re.fullmatch(r"SAMN\d+", accession)
        data = fetch("https://www.ebi.ac.uk/ena/browser/api/xml/"+accession, accession+".xml", args.fetch)
        if not data:
            continue
        tree = ET.fromstring(data)
        for attr in tree.findall(".//SAMPLE_ATTRIBUTE"):
            attributes.append(dict(biosample_acc=accession, source=row.source, year=row.year, AST=row.AST,
                                   database="ENA",
                                   tag=attr.findtext("TAG", ""), value=attr.findtext("VALUE", ""),
                                   units=attr.findtext("UNITS", "")))
    term = " OR ".join(acc+"[Accession]" for acc in sorted(selected.biosample_acc))
    query = urllib.parse.urlencode(dict(db="biosample", term=term, retmode="json", retmax=12))
    result = fetch("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?"+query, "ncbi_search.json", args.fetch)
    if result:
        search = json.loads(result)["esearchresult"]
        ids = search["idlist"]
        if len(ids) != int(search["count"]) or len(ids) > 12:
            raise ValueError("BioSample count mismatch or more than 12 selected records")
        if ids:
            query = urllib.parse.urlencode(dict(db="biosample", id=",".join(ids), retmode="xml"))
            result = fetch("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?"+query, "ncbi_samples.xml", args.fetch)
            if result:
                samples = ET.fromstring(result).findall(".//BioSample")
                if len(samples) != len(ids):
                    raise ValueError("Incomplete BioSample fetch")
                for sample in samples:
                    accession = sample.attrib["accession"]
                    row = selected.loc[selected.biosample_acc.eq(accession)].iloc[0]
                    for attr in sample.findall(".//Attribute"):
                        attributes.append(dict(biosample_acc=accession, source=row.source, year=row.year, AST=row.AST,
                                               database="NCBI_BioSample", tag=attr.attrib.get("attribute_name", ""),
                                               value=attr.text or "", units=attr.attrib.get("unit", "")))
    attrs = pd.DataFrame(attributes)
    attrs.to_csv(OUT / "sample_attributes.csv", index=False)
    if len(attrs):
        relevant = attrs[attrs.tag.str.contains(r"resistan|suscept|amoxi|clav|MIC|breakpoint|laboratory|method", case=False, regex=True)]
        relevant.to_csv(OUT / "AST_attributes.csv", index=False)
        print(relevant.to_string(index=False))
    logs = json.loads((OUT / "requests.json").read_text())
    (OUT / "manifest.json").write_text(json.dumps(dict(
        target_candidate_isolates=len(g), selected_samples=len(selected),
        ENA_samples=int(attrs.loc[attrs.database.eq("ENA"), "biosample_acc"].nunique()),
        NCBI_samples=int(attrs.loc[attrs.database.eq("NCBI_BioSample"), "biosample_acc"].nunique()),
        HTTP_calls=len(logs), HTTP_failures=sum(r["status"] == "failed" for r in logs),
        maximum_HTTP_calls=60, retrieved_sample_records=24,
        metadata_AST_relevant_attributes=len(relevant),
        linked_MIC_dataset_obtained=False, uniform_breakpoint_reclassification_performed=False,
        limitation="Bounded retrieval did not obtain linked MIC or AST protocol data; this is not evidence of public unavailability.",
        source_record_sha256=hashlib.sha256((ROOT.parent / "data/narms_retail_source_records.csv").read_bytes()).hexdigest()),
        indent=2)+"\n", encoding="utf-8")
    print(pd.DataFrame(attempts).to_string(index=False))
    print("Retrieved sample records:", attrs.biosample_acc.nunique() if len(attrs) else 0)


if __name__ == "__main__":
    main()

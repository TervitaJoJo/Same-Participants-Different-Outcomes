"""Independent count, derivative, covariance and denominator checks."""

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from scipy.stats import t
from statsmodels.stats.multitest import multipletests

from composition import candidate, support
from estimators import core, metrics, standardize
from simulation import historical_namespace

ROOT = Path(__file__).resolve().parent


def weighted_probabilities(g, columns, weights):
    labels = g[columns].astype(str).agg("|".join, axis=1).to_numpy()
    q = np.zeros((2, 4))
    state = (2*g.M+g.S).to_numpy(int)
    for key in np.unique(labels):
        members = labels == key
        w = weights[members].sum()/weights.sum()
        for e in [0, 1]:
            selected = members & g.E.to_numpy().__eq__(e)
            counts = np.bincount(state[selected], weights=weights[selected], minlength=4)
            q[e] += w*counts/counts.sum()
    return q


def main():
    checks = {}
    rng = np.random.default_rng(2026101508)
    derivative_error = 0.
    for _ in range(30):
        q = rng.dirichlet(np.ones(4)*2, size=2)
        values, J = metrics(q)
        assert np.max(abs(values-core.joint_metrics(q.ravel())[[6, 7, 8, 9, 10]])) < 1e-10
        numeric = np.empty_like(J)
        for j in range(8):
            shift = np.zeros(8)
            shift[j] = 1e-6
            numeric[:, j] = (metrics(q.ravel()+shift)[0]-metrics(q.ravel()-shift)[0])/2e-6
        derivative_error = max(derivative_error, float(abs(J-numeric).max()))
    assert derivative_error < 1e-7
    checks["analytic_metric_jacobian_max_error"] = derivative_error
    g = candidate()
    max_if_error = 0.
    for columns, known in [(["serovar_clean"], False), (["serovar_clean", "year"], False),
                            (["serovar_clean"], True), (["serovar_clean", "year"], True)]:
        source = g[~g.serovar_clean.eq("Unknown")] if known else g
        part, _ = support(source, columns, 1)
        value, influence, q, ip = standardize(part, columns)
        direct = weighted_probabilities(part, columns, np.ones(len(part)))
        assert abs(direct-q).max() < 1e-12
        picks = sorted(set(np.linspace(0, len(part)-1, 10).astype(int)) |
                       set(np.flatnonzero(part.AST.eq("I").to_numpy() & part.E.eq(1).to_numpy())))
        for index in picks:
            plus, minus = np.ones(len(part)), np.ones(len(part))
            plus[index] += 1e-3
            minus[index] -= 1e-3
            a = metrics(weighted_probabilities(part, columns, plus))[0]
            b = metrics(weighted_probabilities(part, columns, minus))[0]
            error = float(abs((a-b)/2e-3-influence[index]).max())
            max_if_error = max(max_if_error, error)
        assert np.max(abs(influence.sum(axis=0))) < 1e-10
        codes = pd.factorize(part.serovar_clean)[0]
        V, _ = core.cov_cluster(influence, part.assign(strata=1, cluster=codes))
        sums = np.array([influence[codes == code].sum(axis=0) for code in np.unique(codes)])
        sums -= sums.mean(axis=0)
        expected = len(sums)/(len(sums)-1)*sums.T@sums
        assert abs(V-expected).max() < 1e-10
    assert max_if_error < 1e-6
    checks["empirical_target_influence_max_finite_difference_error"] = max_if_error
    checks["cluster_covariance_direct_check"] = "passed"
    synthetic = pd.read_csv(ROOT / "sim/synthetic.csv.gz")
    ns = historical_namespace()
    for rep in range(400):
        observed = synthetic[synthetic.replicate.eq(rep)].drop(columns="replicate").reset_index(drop=True)
        generated = ns["generate"](ns["SCENARIOS"][2], 500, rep)
        pd.testing.assert_frame_equal(observed, generated, check_dtype=False)
    checks["synthetic_replicates_regenerated_identically"] = 400
    attempts = pd.read_csv(ROOT / "sim/attempts.csv")
    assert len(attempts) == 4000
    assert attempts.groupby(["method", "metric"]).size().eq(400).all()
    empirical = attempts[attempts.method.eq("empirical_joint")]
    assert empirical.point_finite.all()
    assert int(empirical.loc[empirical.metric.eq("delta"), "interval_valid"].sum()) == 359
    states = synthetic.assign(U=synthetic.M.eq(1) & synthetic.S.eq(0),
                              V=synthetic.M.eq(0) & synthetic.S.eq(1)).groupby("replicate")[["U", "V"]].sum()
    assert int(states.sum(axis=1).eq(0).sum()) == 41
    assert int(states.U.eq(0).sum()) == 95
    assert int(states.V.eq(0).sum()) == 158
    both = attempts[attempts.method.eq("saturated_paired_binary")].sort_values("replicate")
    emp = empirical[empirical.metric.eq("delta")].sort_values("replicate")
    assert abs(both.estimate.to_numpy()-emp.estimate.to_numpy()).max() < 1e-7
    assert abs(both.se.to_numpy()-emp.se.to_numpy()).max() < 1e-7
    checks["sparse_zero_variance_counts"] = dict(no_discordance=41, no_U=95, no_V=158)
    hist = attempts[attempts.method.eq("historical_screen") & attempts.metric.eq("delta")]
    assert int(hist.interval_valid.sum()) == 12
    assert int(hist.covered.fillna(False).sum()) == 12
    checks["historical_12_400_reproduced"] = True
    cluster = pd.read_csv(ROOT / "cluster/all168.csv")
    original = pd.read_csv(ROOT.parent / "exploratory/threshold_results/cumulative_168_comparisons.csv")
    keys = ["comparison_family", "drug", "reference_source", "exposed_source"]
    assert len(cluster) == 168 and not cluster[keys].duplicated().any()
    merged = cluster.merge(original, on=keys, suffixes=("_new", "_old"), validate="one_to_one")
    assert len(merged) == 168 and (merged.n_new == merged.n_old).all()
    finite = merged.delta_new.notna()
    assert abs(merged.loc[finite, "delta_new"]-merged.loc[finite, "delta_old"]).max() < 1e-10
    recalculated = multipletests(cluster.cluster_p, method="holm")[1]
    assert abs(recalculated-cluster.cluster_holm168).max() < 1e-12
    for row in cluster[cluster.cluster_status.eq("ok")].itertuples():
        expected = 2*t.sf(abs(row.delta)/row.delta_se_cluster, row.cluster_df)
        assert abs(expected-row.cluster_p) < 1e-12
    assert cluster.loc[cluster.cluster_status.ne("ok"), "cluster_p"].eq(1).all()
    assert cluster[cluster.point_reversal].cluster_holm168.ge(.05).all()
    checks["all_168_comparisons_preserved_and_cluster_Holm_verified"] = True
    logs = json.loads((ROOT / "provenance/requests.json").read_text())
    assert len(logs) <= 60
    for entry in logs:
        if entry["status"] != "failed":
            path = ROOT / "provenance/cache" / entry["cache_file"]
            assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"]
    selected = pd.read_csv(ROOT / "provenance/selected_samples.csv")
    attributes = pd.read_csv(ROOT / "provenance/sample_attributes.csv")
    assert len(selected) == 12 and selected.biosample_acc.nunique() == 12
    for database in ["ENA", "NCBI_BioSample"]:
        assert set(attributes.loc[attributes.database.eq(database), "biosample_acc"]) == set(selected.biosample_acc)
    assert len(pd.read_csv(ROOT / "provenance/AST_attributes.csv")) == 0
    checks["official_sample_records_verified"] = dict(ENA=12, NCBI_BioSample=12, HTTP_calls=len(logs))
    counts = {str(p.relative_to(ROOT.parent.parent)): sum(f.is_file() for f in p.iterdir())
              for p in [ROOT.parent.parent, *[p for p in ROOT.parent.parent.rglob("*") if p.is_dir()]]}
    assert max(counts.values()) < 100
    checks["maximum_files_per_directory"] = max(counts.values())
    checks["verification"] = "passed"
    (ROOT / "verification.json").write_text(json.dumps(checks, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()

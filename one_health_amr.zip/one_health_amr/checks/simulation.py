"""Calibrate historical screening on the identical 400 synthetic datasets."""

import os
for key in ["OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"]:
    os.environ[key] = "1"

import ast
import hashlib
import json
import platform
import sys
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import statsmodels
from scipy.optimize import brentq
from scipy.special import expit, logit, ndtr
from statsmodels.stats.proportion import proportion_confint

from estimators import core, standardize

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "sim"
SOURCE = ROOT / "source" / "historical_sim.txt"


def historical_namespace():
    tree = ast.parse(SOURCE.read_text(encoding="utf-8-sig"))
    variables = {"XVALUES", "XWEIGHTS", "SEED", "REPS", "SIZES", "P0", "P1", "SCENARIOS"}
    functions = {"softmax_logits", "generating_prob", "independent_metrics", "scenario_truth",
                 "copula_uniform", "generate", "support_check", "estimate"}
    nodes = [node for node in tree.body if (
        isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in variables for t in node.targets)
        or isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "scenario"
        or isinstance(node, ast.FunctionDef) and node.name in functions)]
    ns = dict(np=np, pd=pd, expit=expit, logit=logit, ndtr=ndtr,
              brentq=brentq, warnings=warnings, joint=core)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), "exec"), ns)
    return ns


def joint_fit(g, screened, history):
    failure, minimum = history["support_check"](g, False)
    if screened and failure:
        return dict(status=failure, minimum_required_cell=minimum)
    caught = []
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            vals, psi, audit = core.multinomial_marginal(g, "smoke_status + x")
        if not np.isfinite(vals).all() or not np.isfinite(psi).all():
            raise ValueError("nonfinite_estimate_or_influence")
        if audit["hessian_condition"] > 1e12:
            raise ValueError("ill_conditioned_hessian")
        if not 0 < audit["min_predicted_state_probability"] < 1:
            raise ValueError("invalid_probability")
        cov, _ = core.cov_cluster(psi[:, 8:11], g)
        if not np.isfinite(cov).all() or (np.diag(cov) <= 0).any():
            raise ValueError("invalid_variance")
        result = dict(status="ok", values=vals[8:11], se=np.sqrt(np.diag(cov)), **audit)
    except Exception as exc:
        location = traceback.extract_tb(exc.__traceback__)[-1]
        result = dict(status="fit_or_check_failure", reason=type(exc).__name__+": "+str(exc),
                      failure_location=f"{Path(location.filename).name}:{location.name}:{location.lineno}",
                      failed_check=location.line)
    result.update(minimum_required_cell=minimum, warning_count=len(caught),
                  warnings=" | ".join(sorted({str(x.message) for x in caught})))
    return result


def binary_fit(g):
    caught = []
    try:
        gg = g.assign(E=(g.smoke_status/2).astype(int))
        vals, influences = [], []
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            for indicator in ["M", "S"]:
                value, psi, audit = core.binary_marginal(gg, gg[indicator], "E*C(x)")
                vals.append(value[3])
                influences.append(psi[:, 3])
        value = vals[1]-vals[0]
        psi = influences[1]-influences[0]
        cov, _ = core.cov_cluster(psi[:, None], gg)
        if not np.isfinite(value) or not np.isfinite(cov).all() or cov[0, 0] < 0:
            raise ValueError("invalid_estimate_or_variance")
        result = dict(status="ok", values=np.array([value]), se=np.sqrt(np.diag(cov)))
    except Exception as exc:
        result = dict(status="fit_or_check_failure", reason=type(exc).__name__+": "+str(exc))
    result.update(warning_count=len(caught), warnings=" | ".join(sorted({str(x.message) for x in caught})))
    return result


def main():
    OUT.mkdir(exist_ok=True)
    history = historical_namespace()
    scenario = history["SCENARIOS"][2]
    truth = history["scenario_truth"](scenario)
    target = np.array([truth[k] for k in ["delta", "CU", "CV"]])
    rows, synthetic = [], []
    max_glm_empirical = 0.
    for rep in range(400):
        g = history["generate"](scenario, 500, rep)
        synthetic.append(g.assign(replicate=rep))
        methods = [("historical_screen", joint_fit(g, True, history), [0, 1, 2]),
                   ("joint_without_screen", joint_fit(g, False, history), [0, 1, 2]),
                   ("saturated_paired_binary", binary_fit(g), [0])]
        gg = g.assign(E=(g.smoke_status/2).astype(int))
        try:
            value, psi, _, _ = standardize(gg, ["x"])
            cov, _ = core.cov_cluster(psi[:, 2:5], gg)
            empirical = dict(status="ok", values=value[2:5], se=np.sqrt(np.maximum(0, np.diag(cov))))
        except Exception as exc:
            empirical = dict(status="support_or_point_failure", reason=str(exc))
        methods.append(("empirical_joint", empirical, [0, 1, 2]))
        if methods[2][1]["status"] == "ok" and empirical["status"] == "ok":
            max_glm_empirical = max(max_glm_empirical, abs(methods[2][1]["values"][0]-empirical["values"][0]),
                                    abs(methods[2][1]["se"][0]-empirical["se"][0]))
        for method, result, indices in methods:
            detail = {k: v for k, v in result.items() if k not in {"values", "se"}}
            for j, index in enumerate(indices):
                row = dict(replicate=rep, method=method, metric=["delta", "C_U", "C_V"][index],
                           target=target[index], point_finite=False, interval_valid=False, **detail)
                if result["status"] == "ok":
                    val, se = result["values"][j], result["se"][j]
                    finite = bool(np.isfinite(val))
                    valid = bool(finite and np.isfinite(se) and se > 0)
                    row.update(estimate=val, se=se, low=val-1.96*se, high=val+1.96*se,
                               point_finite=finite, interval_valid=valid,
                               covered=bool(valid and val-1.96*se <= target[index] <= val+1.96*se))
                    if not valid:
                        row["status"] = "finite_point_zero_variance" if finite and se == 0 else "invalid_point_or_variance"
                rows.append(row)
        if (rep+1) % 50 == 0:
            print(f"Simulation {rep+1}/400", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "attempts.csv", index=False)
    pd.concat(synthetic).to_csv(OUT / "synthetic.csv.gz", index=False, compression={"method": "gzip", "mtime": 0})
    summaries = []
    for (method, metric), part in df.groupby(["method", "metric"], sort=False):
        good = part[part.interval_valid]
        error = good.estimate-good.target
        covered = int(good.covered.fillna(False).sum())
        n = len(good)
        coverage = covered/n if n else np.nan
        point = part[part.point_finite]
        point_error = point.estimate-point.target
        wilson = proportion_confint(covered, n, method="wilson") if n else (np.nan, np.nan)
        summaries.append(dict(method=method, metric=metric, attempts=len(part), finite_points=int(part.point_finite.sum()),
                              valid_intervals=n, covered=covered, interval_success_rate=n/len(part),
                              conditional_coverage=coverage, success_plus_coverage=covered/len(part),
                              bias=error.mean(), bias_mcse=error.std(ddof=1)/np.sqrt(n) if n else np.nan,
                              empirical_sd=error.std(ddof=1), mean_se=good.se.mean(),
                              bias_all_finite_points=point_error.mean(),
                              point_bias_mcse=point_error.std(ddof=1)/np.sqrt(len(point)) if len(point) else np.nan,
                              conditional_coverage_wilson_low=wilson[0], conditional_coverage_wilson_high=wilson[1],
                              coverage_mcse=np.sqrt(coverage*(1-coverage)/n) if n else np.nan,
                              failure_counts=json.dumps(part.loc[~part.interval_valid, "status"].value_counts().to_dict())))
    summary = pd.DataFrame(summaries)
    summary.to_csv(OUT / "summary.csv", index=False)
    df.groupby(["method", "metric", "status"]).size().rename("count").reset_index().to_csv(OUT / "failures.csv", index=False)
    original = df[df.method.eq("historical_screen") & df.metric.eq("delta")]
    assert original.status.value_counts().to_dict() == {"zero_required_state_cell": 385, "ok": 12, "fit_or_check_failure": 3}
    assert max_glm_empirical < 1e-6
    complete = df[df.metric.isin(["delta", "C_U", "C_V"])].groupby(["method", "replicate"]).agg(
        metrics=("metric", "size"), finite_points=("point_finite", "all"), valid_intervals=("interval_valid", "all"))
    complete.to_csv(OUT / "complete_allocation.csv")
    manifest = dict(seed=history["SEED"], scenario_index=2, scenario=scenario, truth=truth, attempts=400, n=500,
                    generator_snapshot_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                    core_sha256=hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
                    synthetic_rows=200000, max_binary_empirical_estimate_or_se_difference=max_glm_empirical,
                    historical_screen_reproduced=True, python=platform.python_version(), numpy=np.__version__,
                    pandas=pd.__version__, scipy=scipy.__version__, statsmodels=statsmodels.__version__)
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()

"""Fixed common-support and coherent three-category composition sensitivities."""

import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

from estimators import core, intervals, metrics, standardize

ROOT = Path(__file__).resolve().parent
AMR = ROOT.parent
OUT = ROOT / "composition"


def candidate():
    return pd.read_csv(AMR / "exploratory/threshold_results/c1_records.csv", keep_default_na=False)


def support(g, columns, minimum):
    counts = g.groupby(columns+["E"]).size().unstack("E", fill_value=0).reindex(columns=[0, 1], fill_value=0)
    keys = counts.index[(counts >= minimum).all(axis=1)]
    obs = pd.MultiIndex.from_frame(g[columns]) if len(columns) > 1 else pd.Index(g[columns[0]])
    return g.loc[obs.isin(keys)].copy().reset_index(drop=True), counts


def multinomial(g, formula):
    g = g.assign(year_c=g.year-g.year.mean())
    X, counterfactual, names = core.matrices(formula, g)
    y = g.AST.map({"S": 0, "I": 1, "R": 2}).to_numpy()
    model = sm.MNLogit(y, X)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = model.fit(method="newton", disp=False, maxiter=150, tol=1e-8)
    params = np.asarray(fit.params)
    flat = params.ravel(order="F")
    if not fit.mle_retvals["converged"] or not np.isfinite(flat).all():
        raise ValueError("nonconverged_or_nonfinite_coefficients; warnings="+" | ".join(str(x.message) for x in caught))
    H = -model.hessian(flat)
    condition = float(np.linalg.cond(H))
    if condition > 1e12:
        raise ValueError(f"ill_conditioned_hessian: {condition}")
    scores = model.score_obs(flat)
    score_error = float(abs(scores.sum(axis=0)).max())
    if score_error > 1e-4:
        raise ValueError(f"failed_score_check: {score_error}")
    ib = scores @ np.linalg.inv(H)
    q = np.zeros((2, 4))
    ip = np.zeros((len(g), 8))
    for level, xx in enumerate(counterfactual):
        p = np.asarray(model.predict(params, xx))
        if not np.isfinite(p).all() or (p <= 0).any() or abs(p.sum(axis=1)-1).max() > 1e-8:
            raise ValueError("invalid_predicted_probability")
        mean = p.mean(axis=0)
        J = np.zeros((3, len(flat)))
        for k in range(3):
            for l in range(1, 3):
                J[k, (l-1)*X.shape[1]:l*X.shape[1]] = np.mean((p[:, k]*((k == l)-p[:, l]))[:, None]*xx, axis=0)
        q[level, [0, 1, 3]] = mean
        ip[:, level*4+np.array([0, 1, 3])] = ib @ J.T+(p-mean)/len(g)
    value, Jm = metrics(q)
    return value, ip @ Jm.T, dict(hessian_condition=condition, score_error=score_error,
                                 parameters=len(flat), warning_count=len(caught),
                                 warnings=" | ".join(sorted({str(x.message) for x in caught})))


def main():
    OUT.mkdir(exist_ok=True)
    g = candidate()
    rows, attempts, probabilities = [], [], []
    full_value, full_if, _, _ = standardize(g, [])
    rows.extend(intervals(g, full_value, full_if, "crude", "all_candidate"))
    targets = [("shared_serovar", ["serovar_clean"], 1),
               ("shared_serovar_year", ["serovar_clean", "year"], 1),
               ("shared_serovar_year_min5", ["serovar_clean", "year"], 5),
               ("known_shared_serovar", ["serovar_clean"], 1),
               ("known_shared_serovar_year", ["serovar_clean", "year"], 1),
               ("known_shared_serovar_year_min5", ["serovar_clean", "year"], 5)]
    retained = {}
    for label, columns, minimum in targets:
        source = g.loc[~g.serovar_clean.eq("Unknown")] if label.startswith("known_") else g
        part, counts = support(source, columns, minimum)
        counts.reset_index().to_csv(OUT / (label+"_support.csv"), index=False)
        retained[label] = part
        meta = dict(target=label, n=len(part), source0_n=int(part.E.eq(0).sum()),
                    source1_n=int(part.E.eq(1).sum()), serovars=part.serovar_clean.nunique(),
                    shared_strata=len(part[columns].drop_duplicates()), minimum=minimum,
                    retained_fraction=len(part)/len(g))
        for model, strata in [("crude_restricted", []), ("empirical_standardization", columns)]:
            try:
                value, influence, q, ip = standardize(part, strata)
                if not np.isfinite(value).all():
                    raise ValueError("undefined_logit_from_zero_or_unit_binary_margin")
                assert np.max(abs(influence.sum(axis=0))) < 1e-10
                assert abs(value[2]-value[3]-value[4]) < 1e-10
                assert abs(value[3]) < 1e-10
                rows.extend(intervals(part, value, influence, model, label))
                attempts.append(dict(meta, model=model, status="ok", point_reversal=bool(value[0]*value[1] < 0)))
                for e in [0, 1]:
                    probabilities.append(dict(target=label, model=model, E=e, p_S=q[e, 0], p_I=q[e, 1], p_R=q[e, 3]))
            except Exception as exc:
                attempts.append(dict(meta, model=model, status="failed", reason=type(exc).__name__+": "+str(exc)))
    shared = retained["shared_serovar"]
    frequency = shared.groupby(["serovar_clean", "E"]).size().unstack("E", fill_value=0)
    eligible = frequency[(frequency >= 5).all(axis=1)]
    top = eligible.sum(axis=1).rename("n").reset_index().sort_values(["n", "serovar_clean"], ascending=[False, True]).head(5).serovar_clean.tolist()
    for label in ["all_shared_serovars", "top5_pool_remainder"]:
        part = shared.copy()
        part["serovar_model"] = part.serovar_clean if label.startswith("all") else part.serovar_clean.where(part.serovar_clean.isin(top), "Pooled_remainder")
        try:
            value, influence, audit = multinomial(part, "E + year_c + C(serovar_model)")
            rows.extend(intervals(part, value, influence, label, "shared_serovar"))
            attempts.append(dict(target="shared_serovar", model=label, status="ok", n=len(part),
                                 point_reversal=bool(value[0]*value[1] < 0), **audit))
        except Exception as exc:
            attempts.append(dict(target="shared_serovar", model=label, status="failed", n=len(part), reason=str(exc)))
    pd.DataFrame(rows).to_csv(OUT / "estimates.csv", index=False)
    pd.DataFrame(attempts).to_csv(OUT / "attempts.csv", index=False)
    pd.DataFrame(probabilities).to_csv(OUT / "probabilities.csv", index=False)
    (OUT / "manifest.json").write_text(json.dumps(dict(n=len(g), top5_serovars=top,
        inference_conditional_on_fixed_support=True, target_weights_estimated=True,
        structural_U_zero=True, no_new_drug_or_source_search=True), indent=2)+"\n", encoding="utf-8")
    print(pd.DataFrame(attempts).to_string(index=False))
    show = pd.DataFrame(rows)
    print(show[show.metric.isin(["logOR_M", "logOR_S", "delta"]) & show.uncertainty.eq("serovar_cluster")].to_string(index=False))


if __name__ == "__main__":
    main()

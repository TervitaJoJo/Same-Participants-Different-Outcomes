"""Use the same serovar-cluster uncertainty and Holm family for all 168 tests."""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t
from statsmodels.stats.multitest import multipletests

from estimators import core

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "exploratory"))
from scan_reversals import paired_estimates


def main():
    out = ROOT / "cluster"
    out.mkdir(exist_ok=True)
    exploratory = ROOT.parent / "exploratory"
    original = pd.read_csv(exploratory / "threshold_results/cumulative_168_comparisons.csv")
    record_paths = {"phenotype_vs_catalog_marker": exploratory / "results/all_drug_paired_records.csv",
                    "R_vs_R_or_I": exploratory / "threshold_results/all_threshold_paired_records.csv"}
    records = {k: pd.read_csv(v, keep_default_na=False) for k, v in record_paths.items()}
    rows = []
    for row in original.to_dict("records"):
        part = records[row["comparison_family"]]
        g = part[part.drug.eq(row["drug"]) & part.source.isin([row["reference_source"], row["exposed_source"]])].copy().reset_index(drop=True)
        g["E"] = g.source.eq(row["exposed_source"]).astype(int)
        result = dict(drug=row["drug"], comparison_family=row["comparison_family"],
                      reference_source=row["reference_source"], exposed_source=row["exposed_source"],
                      n=len(g), point_reversal=row["point_reversal"], independent_status=row["status"],
                      independent_p=row["delta_p"], independent_holm168=row["delta_p_holm_cumulative"],
                      cluster_status="nonestimable", cluster_p=1., both_opposite_cluster95=False,
                      both_opposite_cluster_family=False)
        try:
            values, psi = paired_estimates(g, family_size=168)
            influence = np.column_stack([psi, psi[:, 1]-psi[:, 0]])
            cluster = pd.factorize(g.serovar_clean)[0]
            if len(np.unique(cluster)) < 2:
                raise ValueError("fewer_than_two_serovar_clusters")
            cov, df = core.cov_cluster(influence, g.assign(strata=1, cluster=cluster))
            se = np.sqrt(np.maximum(0, np.diag(cov)))
            critical = t.ppf(.975, df)
            simultaneous = t.ppf(1-.05/(4*168), df)
            delta = values["delta"]
            if not np.isfinite(se).all():
                raise ValueError("invalid_cluster_variance")
            p = float(2*t.sf(abs(delta)/se[2], df)) if se[2] > 1e-14 else 1.
            result.update(cluster_status="ok" if se[2] > 1e-14 else "zero_paired_variance",
                          clusters=len(np.unique(cluster)), cluster_df=df, cluster_p=p,
                          delta=delta, delta_se_cluster=se[2], delta_low=delta-critical*se[2],
                          delta_high=delta+critical*se[2], OR_M=values["OR_M"], OR_S=values["OR_S"])
            for j, indicator in enumerate(["M", "S"]):
                val = values["logOR_"+indicator]
                result[f"logOR_{indicator}"] = val
                for name, z in [("95", critical), ("family", simultaneous)]:
                    result[f"logOR_{indicator}_low_{name}"] = val-z*se[j]
                    result[f"logOR_{indicator}_high_{name}"] = val+z*se[j]
            for name in ["95", "family"]:
                result[f"both_opposite_cluster{name if name == '95' else '_family'}"] = bool(row["point_reversal"] and all(
                    result[f"logOR_{v}_low_{name}"] > 0 or result[f"logOR_{v}_high_{name}"] < 0 for v in ["M", "S"]))
        except (ValueError, AssertionError) as exc:
            result["reason"] = str(exc)
        rows.append(result)
    df = pd.DataFrame(rows)
    assert len(df) == 168
    df["cluster_holm168"] = multipletests(df.cluster_p, method="holm")[1]
    df["cluster_holm_significant"] = df.cluster_holm168.lt(.05)
    df.to_csv(out / "all168.csv", index=False)
    df[df.point_reversal].to_csv(out / "reversals.csv", index=False)
    manifest = dict(comparisons=len(df), status_counts=df.cluster_status.value_counts().to_dict(),
                    point_reversals=int(df.point_reversal.sum()),
                    reversals_cluster_holm168=int((df.point_reversal & df.cluster_holm_significant).sum()),
                    both_opposite_cluster95=int(df.both_opposite_cluster95.sum()),
                    both_opposite_cluster_family=int(df.both_opposite_cluster_family.sum()),
                    nonestimable_p_is_one=True, variance="serovar cluster IF, finite cluster correction, t reference")
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    print(df.loc[df.point_reversal, ["drug", "reference_source", "exposed_source", "delta", "delta_low", "delta_high", "cluster_p", "cluster_holm168"]].to_string(index=False))


if __name__ == "__main__":
    main()

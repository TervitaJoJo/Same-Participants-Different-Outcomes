"""Reproduce the prespecified public food-source AMR paired-state analyses."""

import os
for env_name in ["OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"]:
    os.environ.setdefault(env_name, "1")

import hashlib
import json
import platform
import warnings
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import statsmodels
from scipy.special import logit

import paired_core as core


BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "results"
SEED = 2026101501
STATE_LABELS = ["00", "V", "U", "11"]
MISSING = {"", "NULL", "missing", "not provided", "not collected", "N/A", "NA"}
METRICS = ["logOR_M", "logOR_S", "delta_m", "C_U", "C_V", "kappa", "disagreement"]


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def catalog_mapping():
    catalog = pd.read_csv(DATA / "ReferenceGeneCatalog_2025-12-03.1.tsv", sep="\t", dtype=str, keep_default_na=False)
    eligible = catalog[
        catalog.scope.eq("core") & catalog["type"].eq("AMR")
        & catalog["class"].str.split("/").map(lambda value: "TETRACYCLINE" in value)
        & (catalog.whitelisted_taxa.eq("") | catalog.whitelisted_taxa.str.contains("Salmonella", regex=False))
        & ~catalog.blacklisted_taxa.str.contains("Salmonella", regex=False)
    ].copy()
    eligible.to_csv(OUT / "tetracycline_catalog_mapping.csv", index=False)
    return (set(eligible.allele) | set(eligible.gene_family)) - {""}


def genomic_indicator(value, mapping):
    if value in MISSING:
        return 0, "", ""
    complete, ambiguous = [], []
    for entry in value.split(","):
        symbol, _, flag = entry.strip().partition("=")
        if symbol in mapping:
            (ambiguous if "PARTIAL" in flag else complete).append(symbol)
        elif symbol.casefold().startswith("tet("):
            ambiguous.append(symbol)
    if complete:
        return 1, ";".join(sorted(set(complete))), ";".join(sorted(set(ambiguous)))
    if ambiguous:
        return -1, "", ";".join(sorted(set(ambiguous)))
    return 0, "", ""


def tetracycline_ast(value):
    if value in MISSING:
        return "missing"
    pairs = [item.rsplit("=", 1) for item in value.split(",") if "=" in item]
    results = [result for drug, result in pairs if drug.casefold() == "tetracycline"]
    if len(set(results)) > 1:
        return "conflict"
    return results[0] if results else "untested"


def prepare():
    raw = pd.read_csv(DATA / "narms_retail_source_records.csv", dtype=str, keep_default_na=False)
    mapping = catalog_mapping()
    indicators = [genomic_indicator(value, mapping) for value in raw.AMR_genotypes]
    raw[["S", "mapped_genes", "ambiguous_genes"]] = pd.DataFrame(indicators, index=raw.index)
    raw["AST"] = raw.AST_phenotypes.map(tetracycline_ast)
    raw["source"] = raw.isolation_source.str.casefold().str.split().str.join(" ")
    raw["year"] = pd.to_numeric(raw.collection_date.str.extract(r"^(\d{4})", expand=False), errors="coerce")
    raw["serovar_clean"] = raw.serovar.where(~raw.serovar.isin(MISSING), "Unknown")
    raw["genome_length"] = pd.to_numeric(raw.asm_stats_length_bp, errors="coerce")
    raw["contigs"] = pd.to_numeric(raw.asm_stats_n_contig, errors="coerce")
    raw["n50"] = pd.to_numeric(raw.asm_stats_contig_n50, errors="coerce")
    raw["qc_pass"] = raw.genome_length.between(4_000_000, 6_000_000) & raw.contigs.le(500) & raw.n50.ge(20_000)
    flow = []

    def retain(frame, mask, stage):
        selected = frame.loc[mask].copy()
        flow.append({"stage": stage, "input_rows": len(frame), "excluded_rows": len(frame)-len(selected), "remaining_rows": len(selected)})
        return selected

    frame = retain(raw, raw.geo_loc_name.str.split(":").str[0].eq("USA"), "USA collection location")
    frame = retain(frame, frame.year.between(2002, 2023), "Collection year 2002-2023")
    frame = retain(frame, ~frame.biosample_acc.isin(MISSING), "BioSample present")
    frame = retain(frame, frame.amrfinder_applied.eq("1"), "AMRFinderPlus completed")
    frame = retain(frame, frame.refgene_db_version.eq("2025-12-03.1"), "Pinned reference database")
    conflict_columns = ["source", "AST", "S", "year", "serovar_clean"]
    conflicts = frame.groupby("biosample_acc")[conflict_columns].nunique().gt(1).any(axis=1)
    conflict_ids = conflicts[conflicts].index
    frame = retain(frame, ~frame.biosample_acc.isin(conflict_ids), "Exclude conflicting BioSamples")
    before = len(frame)
    frame = frame.sort_values(["n50", "contigs", "target_acc"], ascending=[False, True, True]).drop_duplicates("biosample_acc")
    flow.append({"stage": "Deduplicate BioSample", "input_rows": before, "excluded_rows": before-len(frame), "remaining_rows": len(frame)})
    frame = retain(frame, frame.S.ge(0), "Unambiguous catalog-defined genomic indicator")
    frame = retain(frame, frame.AST.isin(["R", "S", "I"]), "Tetracycline AST R/S/I")
    frame["year"] = frame.year.astype(int)
    frame["S"] = frame.S.astype(int)
    frame["M"] = frame.AST.eq("R").astype(int)
    frame.to_csv(DATA / "analytic_candidates.csv", index=False)
    main = retain(frame, frame.AST.isin(["R", "S"]), "Primary excludes intermediate AST")
    main = retain(main, main.qc_pass, "Primary assembly quality")
    main.to_csv(DATA / "analytic_primary.csv", index=False)
    pd.DataFrame(flow).to_csv(OUT / "sample_flow.csv", index=False)
    raw.groupby(["source", "AST"], dropna=False).size().rename("n").reset_index().to_csv(OUT / "ast_availability_by_source.csv", index=False)
    raw.groupby(["source", "year", "AST"], dropna=False).size().rename("n").reset_index().to_csv(OUT / "ast_availability_by_year.csv", index=False)
    frame.groupby(["source", "year", "AST"], dropna=False).size().rename("n").reset_index().to_csv(OUT / "year_source_counts.csv", index=False)
    gene_counts = Counter(gene for value in frame.mapped_genes for gene in value.split(";") if gene)
    pd.DataFrame(gene_counts.most_common(), columns=["determinant", "isolates"]).to_csv(OUT / "observed_tetracycline_determinants.csv", index=False)
    return frame, main


def counts_by_source(frame, source):
    group = frame[frame.source.isin(["chicken breast", source])].copy()
    group["E"] = group.source.eq(source).astype(int)
    group["state"] = 2*group.M+group.S
    counts = np.array([np.bincount(group.loc[group.E.eq(e), "state"], minlength=4) for e in [0, 1]])
    return group, counts


def values_from_counts(counts):
    counts = np.asarray(counts)
    totals = counts.sum(axis=1)
    if np.any(totals == 0):
        raise ValueError("empty_source_group")
    p = counts / totals[:, None]
    # Reuse the manuscript's exact order-symmetric allocation.
    vals = core.joint_metrics(p.ravel())
    pooled = counts.sum(axis=0) / counts.sum()
    m = pooled[2]+pooled[3]
    s = pooled[1]+pooled[3]
    po = pooled[0]+pooled[3]
    pe = m*s+(1-m)*(1-s)
    kappa = (po-pe)/(1-pe) if pe < 1 else np.nan
    return np.r_[vals[6:11], kappa, pooled[1]+pooled[2]]


def table_bootstrap(group, counts, method, attempts, seed):
    rng = np.random.default_rng(seed)
    if method == "source_stratified_isolate":
        draws = np.stack([rng.multinomial(int(row.sum()), row/row.sum(), size=attempts) for row in counts], axis=1)
    else:
        serovars = sorted(group.serovar_clean.unique())
        cube = np.zeros((len(serovars), 2, 4), dtype=int)
        positions = {name:i for i, name in enumerate(serovars)}
        for row in group.itertuples():
            cube[positions[row.serovar_clean], row.E, row.state] += 1
        draws = np.array([cube[rng.integers(0, len(cube), size=len(cube))].sum(axis=0) for _ in range(attempts)])
    records = []
    for rep, draw in enumerate(draws):
        result = {"replicate": rep, "status": "ok", "minimum_cell": int(draw.min())}
        if draw.min() == 0:
            result["status"] = "zero_required_source_state_cell"
        else:
            try:
                values = values_from_counts(draw)
                if not np.isfinite(values).all():
                    raise ValueError("nonfinite_estimate")
                result.update(dict(zip(METRICS, values)))
            except (ValueError, AssertionError, FloatingPointError) as exc:
                result["status"] = str(exc)
        records.append(result)
    return pd.DataFrame(records)


def unadjusted(frame, source, analysis, seed, block=False):
    group, counts = counts_by_source(frame, source)
    common = {"analysis": analysis, "exposed_source": source, "reference_source": "chicken breast", "n":len(group)}
    states = [dict(common, source=("chicken breast" if e == 0 else source), state=STATE_LABELS[s], n=int(counts[e,s])) for e in range(2) for s in range(4)]
    status = "ok" if counts.min() > 0 else "zero_required_source_state_cell"
    attempt = dict(common, model="saturated_source_only", status=status, minimum_cell=int(counts.min()), identity_error=None)
    if status != "ok":
        return [], states, [attempt], []
    point = values_from_counts(counts)
    attempt["identity_error"] = float(abs(point[2]-point[3]-point[4]))
    results, denominators = [], []
    methods = [("source_stratified_isolate", 2000, seed)]
    if block:
        methods.append(("serovar_block", 1000, seed+1))
    for method, reps, boot_seed in methods:
        draws = table_bootstrap(group, counts, method, reps, boot_seed)
        draws.to_csv(OUT / f"bootstrap_{analysis}_{method}.csv", index=False)
        good = draws[draws.status.eq("ok")]
        denominator = dict(common, uncertainty=method, attempts=reps, successful=len(good), failed=reps-len(good), success_fraction=len(good)/reps, seed=boot_seed)
        denominators.append(denominator)
        if len(good) >= 2:
            low, high = good[METRICS].quantile([.025, .975]).to_numpy()
        else:
            low = high = np.full(len(METRICS), np.nan)
        for j, metric in enumerate(METRICS):
            results.append(dict(common, metric=metric, estimate=float(point[j]), low=float(low[j]), high=float(high[j]), uncertainty=method, successful_bootstraps=len(good), attempted_bootstraps=reps))
    return results, states, [attempt], denominators


def diagnose_adjusted_failure(group, formula):
    import statsmodels.api as sm
    from patsy import dmatrix

    design = np.asarray(dmatrix(formula, group), float)
    model = sm.MNLogit(2*group.M+group.S, design)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = model.fit(method="newton", disp=False, maxiter=150, tol=1e-8)
    flat = np.asarray(fit.params).ravel(order="F")
    hessian = -model.hessian(flat)
    output = {
        "optimizer_converged": bool(fit.mle_retvals["converged"]),
        "iterations": int(fit.mle_retvals["iterations"]),
        "warning_count": len(caught),
        "finite_coefficients": bool(np.isfinite(flat).all()),
        "nonfinite_coefficient_count": int((~np.isfinite(flat)).sum()),
        "max_abs_coefficient": float(np.max(np.abs(flat))) if np.isfinite(flat).all() else None,
    }
    if np.isfinite(hessian).all():
        output["diagnostic_hessian_condition"] = float(np.linalg.cond(hessian))
    if not np.isfinite(flat).all():
        output["reason"] = "nonfinite_coefficients_despite_optimizer_convergence" if output["optimizer_converged"] else "nonfinite_coefficients"
    return output


def adjusted(frame, model_name, formula):
    group, counts = counts_by_source(frame, "ground turkey")
    group = group.reset_index(drop=True)
    group["smoke_status"] = group.E
    group["year_c"] = group.year-group.year.mean()
    top = group.serovar_clean.value_counts().rename_axis("serovar").reset_index(name="n").sort_values(["n", "serovar"], ascending=[False, True]).head(10).serovar
    group["serovar_group"] = group.serovar_clean.where(group.serovar_clean.isin(top), "Other_or_unknown")
    if "serovar_group" in formula:
        group.groupby(["source", "serovar_group", "state"]).size().rename("n").reset_index().to_csv(OUT / "adjusted_serovar_state_support.csv", index=False)
    group["strata"] = 1
    group["cluster"] = np.arange(len(group))
    audit = {"analysis":model_name, "exposed_source":"ground turkey", "reference_source":"chicken breast", "n":len(group), "model":formula, "status":"ok"}
    results = []
    if counts.min() == 0:
        audit["status"] = "zero_required_source_state_cell"
        return results, audit
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            values, psi, diagnostics = core.multinomial_marginal(group, formula, levels=(0,1))
        audit.update(diagnostics, warning_count=len(caught))
        if diagnostics["hessian_condition"] > 1e12:
            raise ValueError("ill_conditioned_hessian")
        if not np.isfinite(values).all() or not np.isfinite(psi).all() or not 0 < diagnostics["min_predicted_state_probability"] < 1:
            raise ValueError("invalid_fitted_probabilities_or_influence")
        for uncertainty in ["isolate_influence", "serovar_cluster_influence"]:
            covariance_group = group.copy()
            if uncertainty == "serovar_cluster_influence":
                covariance_group["cluster"] = pd.factorize(group.serovar_clean)[0]
            cov, df = core.cov_cluster(psi[:,6:11], covariance_group)
            if not np.isfinite(cov).all() or np.any(np.diag(cov) <= 0):
                raise ValueError("invalid_variance")
            critical = scipy.stats.t.ppf(.975, df) if uncertainty.startswith("serovar") else 1.959963984540054
            for metric, estimate, se in zip(METRICS[:5], values[6:11], np.sqrt(np.diag(cov))):
                results.append({"analysis":model_name, "exposed_source":"ground turkey", "reference_source":"chicken breast", "n":len(group), "metric":metric, "estimate":float(estimate), "low":float(estimate-critical*se), "high":float(estimate+critical*se), "uncertainty":uncertainty, "df":int(df)})
    except (ValueError, AssertionError, np.linalg.LinAlgError, FloatingPointError) as exc:
        audit["status"] = "model_or_diagnostic_failure"
        audit["reason"] = str(exc) or type(exc).__name__
        try:
            audit.update(diagnose_adjusted_failure(group, formula))
        except (ValueError, np.linalg.LinAlgError) as diagnostic_exc:
            audit["diagnostic_error"] = str(diagnostic_exc)
        results = []
    return results, audit


def main():
    OUT.mkdir(exist_ok=True)
    candidates, primary = prepare()
    ns = candidates[candidates.qc_pass].copy()
    ns["M"] = ns.AST.isin(["R", "I"]).astype(int)
    no_qc = candidates[candidates.AST.isin(["R", "S"])].copy()
    specs = [(primary, "ground turkey", "primary_turkey", True),
             (primary, "ground beef", "secondary_beef", False),
             (primary, "pork chop", "secondary_pork", False),
             (ns, "ground turkey", "sensitivity_nonsusceptible", False),
             (no_qc, "ground turkey", "sensitivity_no_extra_qc", False)]
    estimates, states, fits, denominators, descriptive = [], [], [], [], []
    for i, (frame, source, name, block) in enumerate(specs):
        print(f"Analyzing {name}: {len(frame)} candidate isolates", flush=True)
        rows, cells, attempts, boot = unadjusted(frame, source, name, SEED+100*i, block)
        estimates.extend(rows); states.extend(cells); fits.extend(attempts); denominators.extend(boot)
        group, counts = counts_by_source(frame, source)
        # A boundary estimate can be finite even when the prespecified
        # full-state inference screen is not satisfied.
        point = values_from_counts(counts)
        for metric, value in zip(METRICS, point):
            descriptive.append({"analysis":name, "metric":metric, "estimate":float(value),
                                "n":len(group), "full_state_support":bool(counts.min() > 0)})
    for name, formula in [("adjusted_year", "smoke_status + year_c"), ("adjusted_year_serovar", "smoke_status + year_c + C(serovar_group)")]:
        print(f"Analyzing {name}", flush=True)
        rows, audit = adjusted(primary, name, formula)
        estimates.extend(rows); fits.append(audit)
    pd.DataFrame(estimates).to_csv(OUT / "paired_estimates.csv", index=False)
    pd.DataFrame(states).to_csv(OUT / "state_counts.csv", index=False)
    pd.DataFrame(fits).to_csv(OUT / "model_attempts.csv", index=False)
    pd.DataFrame(denominators).to_csv(OUT / "bootstrap_denominators.csv", index=False)
    pd.DataFrame(descriptive).to_csv(OUT / "descriptive_point_estimates.csv", index=False)
    primary.groupby(["source", "serovar_clean"]).size().rename("n").reset_index().to_csv(OUT / "serovar_source_counts.csv", index=False)
    manifest = {
        "python":platform.python_version(), "numpy":np.__version__, "pandas":pd.__version__,
        "scipy":scipy.__version__, "statsmodels":statsmodels.__version__, "seed":SEED,
        "primary_isolates_all_sources":len(primary), "candidate_isolates_all_sources":len(candidates),
        "unique_primary_biosamples":int(primary.biosample_acc.nunique()),
        "primary_source_counts":{k:int(v) for k,v in primary.source.value_counts().items()},
        "primary_year_min":int(primary.year.min()), "primary_year_max":int(primary.year.max()),
        "point_model_attempts":len(fits), "point_model_successes":sum(fit["status"] == "ok" for fit in fits),
        "core_source":"mechanism_followup_20260917/code/common.py; unmodified local copy paired_core.py",
        "core_sha256":hashlib.sha256((BASE / "paired_core.py").read_bytes()).hexdigest(),
        "input_sha256":hashlib.sha256((DATA / "narms_retail_source_records.csv").read_bytes()).hexdigest(),
        "estimation_scope":"Descriptive source associations in publicly sequenced eligible NARMS records",
        "protocol":"ANALYSIS_PLAN.md; record any deviations separately",
    }
    write_json(OUT / "analysis_manifest.json", manifest)
    print(json.dumps(manifest, indent=2), flush=True)


if __name__ == "__main__":
    main()

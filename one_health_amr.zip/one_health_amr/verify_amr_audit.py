"""Independent checks of pairing, allocation, interval denominators and reuse."""

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import logit

import paired_core as core
from run_amr_audit import counts_by_source, values_from_counts


BASE = Path(__file__).resolve().parent
OUT = BASE / "results"


def main():
    data = pd.read_csv(BASE / "data" / "analytic_primary.csv", keep_default_na=False)
    assert data.biosample_acc.is_unique
    assert data.M.isin([0,1]).all() and data.S.isin([0,1]).all()
    group, counts = counts_by_source(data, "ground turkey")
    assert counts.sum() == len(group)
    v = values_from_counts(counts)
    x = sm.add_constant(group.E)
    lm = sm.GLM(group.M, x, family=sm.families.Binomial()).fit().params["E"]
    ls = sm.GLM(group.S, x, family=sm.families.Binomial()).fit().params["E"]
    np.testing.assert_allclose(v[:3], [lm, ls, ls-lm], atol=1e-10)

    # Independently enumerate the two possible orders of changing the states.
    p = counts/counts.sum(axis=1, keepdims=True)
    m = p[:,2]+p[:,3]
    s = p[:,1]+p[:,3]
    both = p[:,3]
    either = 1-p[:,0]
    L = lambda q: float(logit(q[1])-logit(q[0]))
    cu = ((L(both)-L(m))+(L(s)-L(either)))/2
    cv = ((L(either)-L(m))+(L(s)-L(both)))/2
    np.testing.assert_allclose(v[3:5], [cu, cv], atol=1e-12)
    np.testing.assert_allclose(v[2], cu+cv, atol=1e-12)
    swapped = values_from_counts(counts[:,[0,2,1,3]])
    np.testing.assert_allclose(swapped[2:5], [-v[2],-v[4],-v[3]], atol=1e-12)
    np.testing.assert_allclose(values_from_counts(counts[::-1])[:5], -v[:5], atol=1e-12)

    # Saturated fitted model must reproduce the empirical joint table.
    fitted = group.assign(smoke_status=group.E, strata=1, cluster=np.arange(len(group)))
    joint, influence, diagnostics = core.multinomial_marginal(fitted, "smoke_status", levels=(0,1))
    np.testing.assert_allclose(joint[6:11], v[:5], atol=1e-9)
    binary_cov = [fit for fit in [
        sm.GLM(group.M, x, family=sm.families.Binomial()).fit(),
        sm.GLM(group.S, x, family=sm.families.Binomial()).fit(),
    ]]
    cov, _ = core.cov_cluster(influence[:,6:11], fitted)
    # Finite-sample cluster correction is n/(n-1) for singleton clusters.
    for j in [0,1]:
        expected = binary_cov[j].cov_params().loc["E","E"]*len(group)/(len(group)-1)
        np.testing.assert_allclose(cov[j,j], expected, rtol=2e-7)
    independent_difference_variance = cov[0,0]+cov[1,1]
    paired_difference_variance = cov[2,2]
    assert paired_difference_variance < independent_difference_variance

    denominators = pd.read_csv(OUT / "bootstrap_denominators.csv")
    for row in denominators.itertuples():
        draws = pd.read_csv(OUT / f"bootstrap_{row.analysis}_{row.uncertainty}.csv")
        assert len(draws) == row.attempts
        assert draws.status.eq("ok").sum() == row.successful
        assert row.successful+row.failed == row.attempts
        good = draws[draws.status.eq("ok")]
        np.testing.assert_allclose(good.delta_m, good.C_U+good.C_V, atol=1e-12)
    retrieval = json.loads((BASE / "retrieval_manifest.json").read_text())
    assert retrieval["expected_source_bytes"] == retrieval["retrieved_source_bytes"]
    assert retrieval["analysis_plan_sha256"] == hashlib.sha256((BASE / "ANALYSIS_PLAN.md").read_bytes()).hexdigest()
    assert retrieval["retained_csv_sha256"] == hashlib.sha256((BASE / "data" / "narms_retail_source_records.csv").read_bytes()).hexdigest()
    report = {
        "status":"passed", "primary_isolates":len(group),
        "checks":["unique paired BioSamples", "binary logistic comparison", "independent two-order allocation",
                  "outcome and source relabeling invariance", "saturated joint model agreement",
                  "binary versus joint variance agreement", "paired covariance retained",
                  "all bootstrap attempt counts reconciled", "replicate additivity",
                  "complete source download and frozen plan checksums"],
        "paired_delta_variance":float(paired_difference_variance),
        "variance_if_pairing_ignored":float(independent_difference_variance),
        "saturated_model_identity_error":diagnostics["identity_error"],
    }
    (OUT / "verification.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

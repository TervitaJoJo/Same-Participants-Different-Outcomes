# Public One Health AMR data: bounded feasibility check

## Reviewer checks: read before interpreting the exploratory reversals

The latest assessment is `checks/REPORT_zh.md`. It adds simulation procedure
calibration, common-serovar/year standardization, official AST metadata
checks, and consistent serovar-cluster inference across all 168 exploratory
comparisons. All previous analyses remain intact. The crude candidate
reversal is sensitive to composition and target support, and none of the
five point reversals passes clustered Holm correction over 168 comparisons.

Run the primary analysis, both exploratory searches and all reviewer checks:

```bash
python -B reproduce_amr.py --include-reviewer-checks
```

Run only the reviewer checks from their bundled inputs and snapshots:

```bash
python -B checks/run_checks.py
```

Both run offline. Use `checks/provenance.py --fetch` only to fetch missing
official snapshots; existing snapshots are reused, with the original dates
and checksums preserved. The checks keep all failures and synthetic inputs,
and do not change the manuscript. See `checks/PLAN.md` for the exploratory
analysis amendment, including the subsequent missing-serovar sensitivity.

## Full analysis completed on 2026-10-15

The initial pilot below has been extended to a complete, version-pinned
download and the prespecified NARMS analysis in `ANALYSIS_PLAN.md`.
Read `AMR_analysis_report_zh.md` for the full Chinese interpretation.

For offline reproduction from the included public source subset:

```bash
python -m pip install -r requirements_amr.txt
python reproduce_amr.py
```

This rebuilds the analytical samples, all planned results, paired bootstrap
attempt logs, independent verification, the report and a provisional figure
in PNG (600 dpi) and PDF. No network access or restricted human cohort data
are needed after installing dependencies. The numerical stack was verified
on Python 3.14.5; package versions are recorded in the analysis manifest.

The complete source release contains 897,959 rows (866,098,735 bytes).
`download_full_narms.py` streams this official bulk file and retains only
6,161 records matching the predetermined NARMS and four-source labels.
The final primary dataset has 4,316 unique isolates. The turkey-versus-chicken
comparison uses 3,967 isolates. Actual paired-data years are 2002-2021,
within the predetermined 2002-2023 window.

The primary difference is small and its interval includes zero. No reversal
was found in this primary comparison. Sparse discordant states limit the
chosen full-state inference procedure in secondary comparisons. Finite
descriptive beef estimates are retained separately even though its full-state
inference screen fails. See the report for limitations and failed fits.

The public records are bacterial isolates from food, not human participant
data. The extension does not establish cross-sector transmission.

## Exploratory reversal search (separate from the primary analysis)

The second exploratory family compares submitted R versus R-or-I labels
on the same isolates for all 19 drugs and six source pairs (114 comparisons).
It found four additional point reversals, including amoxicillin-clavulanic
acid for ground beef versus ground turkey (OR 2.113 versus 0.495).
See `exploratory/THRESHOLD_SEARCH_REPORT_zh.md` for all candidates, the
cumulative 168-comparison multiplicity results and dependence checks.
These are threshold comparisons, not phenotype-versus-genotype reversals.
Both exploratory families run with the command below. Submitted I labels
are preserved; no MIC-based breakpoint harmonization is claimed.

`exploratory/EXPLORATORY_PLAN.md` fixes nine drug indicators and all six
source pairs before their new associations were calculated. All 54 planned
comparisons, including zero-event and sparse cases, are retained in
`exploratory/results/all_54_comparisons.csv`. The search identified one
point-estimate reversal (kanamycin, pork chop versus chicken breast), with
uncertain individual directions and no family-adjusted significant paired
difference. See `exploratory/REVERSAL_SEARCH_REPORT_zh.md` for interpretation.

Run the primary workflow plus the exploratory extension with:

```bash
python reproduce_amr.py --include-exploratory
```

To reproduce only the new search and its candidate checks:

```bash
python exploratory/scan_reversals.py
python exploratory/check_candidates.py
python exploratory/scan_thresholds.py
python exploratory/check_threshold_candidates.py
python exploratory/verify_thresholds.py
```

Candidate checks preserve paired outcomes during resampling, account for
serovar dependence, and fit year-adjusted paired binary models. Their
empirical-support bootstrap is distinct from the primary full-state
inference screen; failed primary-screen status remains explicit. No claim
of a statistically established opposite direction follows from the search.

## Original bounded pilot

Run `python fetch_public_amr_pilot.py` with Python 3 and internet access.
Only standard-library modules are required.

The script reads the first 4,000,000 bytes of the version-pinned NCBI
Pathogen Detection Salmonella AMR metadata file. It saves records with
completed AMRFinderPlus analysis and at least one interpreted AST result
(R, S or I), plus a source summary and retrieval manifest. It cross-checks
one sample against the official ENA record.

Files produced:

- `public_salmonella_pilot.csv`: public isolate-level candidate records
- `pilot_source_counts.csv`: source counts within this prefix only
- `availability_manifest.json`: endpoints, filters, counts and provenance

These are public bacterial isolate records, not restricted human cohort
records. They demonstrate data availability; they are not a final analysis
sample. No manuscript or existing reproduction package is changed.

Before analysis, define a species, drug, surveillance project, time window
and source contrast. Map drug-specific resistance determinants using a
documented rule, account for intermediate/untested results, verify genome
quality, and deduplicate isolates. A resistance-gene list is not itself a
drug-specific resistance prediction. Gene nondetection in a completed run
must be distinguished from a missing or failed genomic analysis.

The NCBI `environmental/other` field includes food records. Meat or feed
samples must not be described as water, soil or other environmental samples.
These records also cannot establish transmission between sectors.

Use the official source for citation, provenance and applicable reuse terms:

- https://ftp.ncbi.nlm.nih.gov/pathogen/ReadMe.txt
- https://ftp.ncbi.nlm.nih.gov/pathogen/Results/Salmonella/PDG000000002.4261/AMR/
- https://www.ebi.ac.uk/ena/browser/view/SAMN02640788
